<?php
// Include variables
include 'variables.php';

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// SQL Command
$sql = "SELECT * FROM `$programtable`";

// Check connection
if ($conn->connect_error) {
    die("Connection failed");
}

// Run
$result = $conn->query($sql);
if ($result) {
    $number_of_result = mysqli_num_rows($result);  
    if ($number_of_result > 0) {
        echo '<select name="program" class="selector" id="program"><optgroup class="option2" label="Programs">';
        while ($row = mysqli_fetch_array($result)) {
            $id = $row["ProgramID"];
            $name = $row["Program"];
            if (isset($pid) && !empty($pid) && $pid == $id && $pname == $name && $isInRegisterThesis == 1) {echo '<option class="option2" value="'.$id.'" selected>'.$name.'</option>';}
            else {echo '<option class="option2" value="'.$id.'">'.$name.'</option>';}
        }
        echo '</optgroup></select>';
    }
    else {
        echo '<select name="program" class="selector"><optgroup class="option2" label="Programs">';
        echo '<option class="option2" value="none">Empty program</option>';
        echo '</optgroup></select>';
    }
}

// Close connection
$conn->close();
?>