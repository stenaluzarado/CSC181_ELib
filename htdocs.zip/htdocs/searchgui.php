<?php
    echo '<div class="search_container">';
    include 'title.php';
    echo '</div>
        <form id="searchform2" method="GET" class="search_container2">
        <table cellspacing="0" cellpadding="0" border="0" width="100%">
        <tr id="s2row">
        <td align="right"><input type="text" id="s2" name="s" placeholder="Search by keywords" class="search_bg"/></td>
        <td><input type="submit" id="s2submit" name="submit" value="Go" class="search_btn" style="border-radius:0;"/></td>
        <td><input type="button" id="filterbtn2" name="filterbtn2" value="▼" class="filter_btn" onclick="showFilters()"/></td>
        </tr>
        <tr align="right" valign="top"><td colspan="3">';
        include 'selectfilters.php';
     echo '</td></tr></table></form>';
?>