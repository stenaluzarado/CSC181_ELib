<div class="search_container">
    <?php include 'title.php';?>
    <form action="index.php" method="GET" class="search_form">
        <input type="text" name="s" placeholder="Search by keywords" class="search_bg"/>
        <input type="submit" title="Search" value="Search" class="search_btn"/>
    </form>
</div>
