<?php

session_start();

if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
    if (!isset($_GET['id']) || empty($_GET['id'])) {echo 'Error deleting!'; exit();}

    include 'variables.php';

    $id = trim($_GET['id']);

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    $id = mysqli_real_escape_string($conn, $id);

    // SQL Command
    $sql = "DELETE FROM `$admintable` WHERE AdminID='$id'";

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed");
    }

    // Run
    $result = $conn->query($sql);
    if ($result) {
        $name = $_SESSION['name'];
        $sql = "SELECT AdminID FROM `$admintable` WHERE BINARY Username='$name'";
        $result = $conn->query($sql);
        if ($result) {
            $n = mysqli_num_rows($result);  
            if ($n != 0) {echo 'Success';}
            else {echo 'Logout';}
        }
        else {echo 'Error deleting!';}
    }
    else {echo 'Error deleting!';}

    // Close connection
    $conn->close();
}

?>