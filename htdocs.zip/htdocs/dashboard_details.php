<?php

if (isset($_SESSION['name'])) {echo 'Welcome back <b>'.$_SESSION['name'].'</b>.<br><br>';}

include 'variables.php';
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {echo 'Connection error!';}
else {
    echo '<table cellspacing="0" cellpadding="3" border="0" width="100%" style="font-size:14px;">';
    echo '<tr><td style="font-weight:bold;">Total Thesis:</td>';
    $sql = "SELECT ThesisID FROM `$thesistable`";
    $r = $conn->query($sql);
    if ($r) {$n = mysqli_num_rows($r); echo '<td>'.$n.'</td>';}
    echo '</tr>';

    echo '<tr><td style="font-weight:bold;">Total Author:</td>';
    $sql = "SELECT AuthorID FROM `$authortable`";
    $r = $conn->query($sql);
    if ($r) {$n = mysqli_num_rows($r); echo '<td>'.$n.'</td>';}
    echo '</tr>';

    echo '<tr><td style="font-weight:bold;">Total Degree:</td>';
    $sql = "SELECT DegreeID FROM `$degreetable`";
    $r = $conn->query($sql);
    if ($r) {$n = mysqli_num_rows($r); echo '<td>'.$n.'</td>';}
    echo '</tr>';

    echo '<tr><td style="font-weight:bold;">Total Program:</td>';
    $sql = "SELECT ProgramID FROM `$programtable`";
    $r = $conn->query($sql);
    if ($r) {$n = mysqli_num_rows($r); echo '<td>'.$n.'</td>';}
    echo '</tr>';

    echo '<tr><td style="font-weight:bold;">Total Admin:</td>';
    $sql = "SELECT AdminID FROM `$admintable`";
    $r = $conn->query($sql);
    if ($r) {$n = mysqli_num_rows($r); echo '<td>'.$n.'</td>';}
    echo '</tr>';
    echo '</table>';
}

?>