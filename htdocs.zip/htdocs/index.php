<html>

<head>
    <?php include 'head.php';?>
</head>

<body>
<?php
    include 'getsearchresults.php';
    include 'upperlinks.php';
    include 'footer.php';
?>
</body>

</html>
