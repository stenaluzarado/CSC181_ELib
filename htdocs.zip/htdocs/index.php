<html>

<head>
    <?php include 'head.php';?>
</head>

<body>
    <?php
        include 'searchgui.php';
        include 'upperlinks.php';
    ?>

<?php include 'footer.php';?>

</body>

</html>
