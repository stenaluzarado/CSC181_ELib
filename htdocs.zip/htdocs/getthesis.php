<?php

session_start();

if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
    if (!isset($_POST['title']) || empty($_POST['title']) || !isset($_POST['degree']) || empty($_POST['degree']) || !isset($_POST['author']) || empty($_POST['author']) || !isset($_POST['program']) || empty($_POST['program']) || !isset($_POST['abstract']) || empty($_POST['abstract']) || !isset($_POST['pubyear']) || empty($_POST['pubyear'])) {
        $_SESSION['notif'] = 'eadd';
        header("Location: dashboard.php");
        exit();
    }

    include 'variables.php';

// Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

// SQL Command
    $sql = "SELECT * FROM `$thesistable`";

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed");
    }

// Run
    $result = $conn->query($sql);
    if ($result) {
        $number_of_result = mysqli_num_rows($result);  
        if ($number_of_result == 0) {
                $results_per_page = 20;
                    $number_of_page = ceil($number_of_result/$results_per_page);
                    if (!empty($_GET['page'])) {$page = $_GET['page'];}
                    else {$page = 1;}
                    // To understand the limit part $offset is where the selection starts then comma, then the limit.
                    $offset = ($page-1)*$results_per_page;
                    $sql = "SELECT * FROM `$table` ORDER BY Title LIMIT ".$offset.",".$results_per_page;
                    $result = mysqli_query($conn, $sql);  
                    echo "<table cellpadding='0' cellspacing='0' border='0' id='mainbarstudentlist' class='mainbarstudentlist'>";
                    echo "<tr id='mainbarstudentlistheader' class='mainbarstudentlistheader'><td style='width:13%;'>Title</td><td>Author</td><td>Courses</td><td>Degree</td><td>Year</td><td>Action</td></tr>";
                    while ($row = mysqli_fetch_array($result)) {
                        $id = $row["ID"];
                        $Sname = $row["Title"];
                        echo '<tr valign="top" title="Click to edit"><td onclick="editDialog(\''.$id.'\')">'.$Sname.'</td><td onclick="editDialog(\''.$id.'\')">'.$row["Author"].'</td><td onclick="editDialog(\''.$id.
            '\')">'.$row["Courses"].'</td><td onclick="editDialog(\''.$id.'\')">'.$row["Degree"].'</td><td onclick="editDialog(\''.$id.'\')">'.$row["PublicationYear"].'</td><td align="center" style="padding:5px;" title="Click to delete student"><input class="actionbuttondelete" type="button" value="Delete" onclick="deleteDialog(\''.$Sname.'\', \''.$id.'\')"/></td></tr>';
                    }
                    echo "</table>";
                    mysqli_free_result($result);
                }
                else {
                    echo "<h3 style='margin:40px;color:white;'>No thesis information in database.</h3>";
                }
            }
            else {
                echo "<h3 style='margin:40px;color:white;'>Please create a database and tables.</h3>";
            }  
        }         

    // Close connection
    $conn->close();
}
else {
    $_SESSION['notif'] = 'accessdenied';
    header("Location: index.php");
    exit();
}

?>