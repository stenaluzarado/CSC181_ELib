<?php

session_start();

if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
    if (!isset($_GET['id']) || empty($_GET['id'])) {echo 'Error deleting!'; exit();}

    include 'variables.php';

    $id = trim($_GET['id']);

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    $id = mysqli_real_escape_string($conn, $id);

    // SQL Command
    $sql = "DELETE FROM `$thesistable` WHERE ThesisID='$id'";
    $sql2 = "DELETE FROM `$thesisauthortable` WHERE ThesisID='$id'";
    $sql3 = "DELETE FROM `$authortable` WHERE NOT EXISTS (SELECT 1 FROM `$thesisauthortable` WHERE $thesisauthortable.AuthorID = $authortable.AuthorID)";

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed");
    }

    // Run
    $result = $conn->query($sql);
    if ($result) {
        $result = $conn->query($sql2);
        if ($result) {
            $result = $conn->query($sql3);
            if ($result) {echo 'Success';}
            else {echo 'Error deleting!';}
        }
        else {echo 'Error deleting!';}
    }
    else {echo 'Error deleting!';}

    // Close connection
    $conn->close();
}

?>