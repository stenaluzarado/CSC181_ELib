<?php

session_start();

if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
    if (!isset($_POST['pid']) || empty($_POST['pid']) || !isset($_POST['pname']) || empty($_POST['pname'])) {
        $re = $_POST['re'];
        $_SESSION['notif'] = 'eadd';
        header("Location: dashboard.php?dpage=".$re);
        exit();
    }

    include 'variables.php';

    $pid = $_POST['pid'];
    $pname = $_POST['pname'];
    $re = $_POST['re'];

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    $pid = mysqli_real_escape_string($conn, $pid);
    $pname = mysqli_real_escape_string($conn, $pname);
    $re = mysqli_real_escape_string($conn, $re);

    // SQL Command
    $sql = "SELECT Program FROM `$programtable` WHERE Program='$pname'";
    $sql2 = "INSERT INTO `$programtable` (ProgramID, Program) VALUES ('$pid', '$pname')";

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed");
    }

    // Run
    $result = $conn->query($sql);
    if ($result) {
        $number_of_result = mysqli_num_rows($result);  
        if ($number_of_result == 0) {
            $result2 = $conn->query($sql2);
            if ($result2) {$_SESSION['notif'] = 'sadd';}
            else {$_SESSION['notif'] = 'eadd';}
        }
        else {$_SESSION['notif'] = 'exist';}
    }
    else {$_SESSION['notif'] = 'eadd';}
    header("Location: dashboard.php?dpage=".$re);
    exit();

    // Close connection
    $conn->close();
}
else {
    $_SESSION['notif'] = 'accessdenied';
    header("Location: index.php");
    exit();
}

?>