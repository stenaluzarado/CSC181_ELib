<?php

session_start();

if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
    if (!isset($_POST['uname']) || empty($_POST['uname']) || !isset($_POST['pass']) || empty($_POST['pass'])) {
        $re = $_POST['re'];
        $_SESSION['notif'] = 'eadd';
        header("Location: dashboard.php?dpage=".$re);
        exit();
    }

    include 'variables.php';

    $uname = $_POST['uname'];
    $pass = $_POST['pass'];
    $re = $_POST['re'];

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    $uname = mysqli_real_escape_string($conn, $uname);
    $pass = mysqli_real_escape_string($conn, $pass);
    $re = mysqli_real_escape_string($conn, $re);

    // SQL Command
    $sql = "SELECT Username FROM `$admintable` WHERE BINARY Username='$uname'";
    $sql2 = "INSERT INTO `$admintable` (Username, Password) VALUES ('$uname', '$pass')";

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed");
    }

    // Run
    $result = $conn->query($sql);
    if ($result) {
        $number_of_result = mysqli_num_rows($result);  
        if ($number_of_result == 0) {
            $result2 = $conn->query($sql2);
            if ($result2) {$_SESSION['notif'] = 'sadd';}
            else {$_SESSION['notif'] = 'eadd';}
        }
        else {$_SESSION['notif'] = 'exist';}
    }
    else {$_SESSION['notif'] = 'eadd';}
    header("Location: dashboard.php?dpage=".$re);
    exit();

    // Close connection
    $conn->close();
}
else {
    $_SESSION['notif'] = 'accessdenied';
    header("Location: index.php");
    exit();
}

?>