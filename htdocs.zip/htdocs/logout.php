<?php
    session_start();
    $_SESSION['role'] = '';
    $_SESSION['name'] = '';
    session_destroy();
    header("Location: index.php");
    exit();
?>
