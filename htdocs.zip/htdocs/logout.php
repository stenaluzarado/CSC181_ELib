<?php
    session_start();
    $_SESSION['role'] = '';
    $_SESSION['name'] = '';
    $_SESSION['notif'] = 'logout';
    header("Location: index.php");
    exit();
?>
