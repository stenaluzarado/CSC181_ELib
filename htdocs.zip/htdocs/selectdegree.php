<?php
// Include variables
include 'variables.php';

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// SQL Command
$sql = "SELECT * FROM `$degreetable`";

// Check connection
if ($conn->connect_error) {
    die("Connection failed");
}

// Run
$result = $conn->query($sql);
if ($result) {
    $number_of_result = mysqli_num_rows($result);  
    if ($number_of_result > 0) {
        echo '<select name="degree" class="addinput_bg"><optgroup label="Degrees">';
        while ($row = mysqli_fetch_array($result)) {
            $id = $row["DegreeID"];
            $name = $row["Degree"];
            echo '<option value="'.$id.'">'.$name.'</option>';
        }
        echo '</optgroup></select>';
    }
    else {
        echo '<select name="degree" class="addinput_bg"><optgroup label="Degrees">';
        echo '<option value="none">Empty degree</option>';
        echo '</optgroup></select>';
    }
}

// Close connection
$conn->close();
?>