<?php
// Include variables
include 'variables.php';

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// SQL Command
$sql = "SELECT * FROM `$degreetable`";

// Check connection
if ($conn->connect_error) {
    die("Connection failed");
}

// Run
$result = $conn->query($sql);
if ($result) {
    $number_of_result = mysqli_num_rows($result);  
    if ($number_of_result > 0) {
        echo '<select name="degree" class="selector" id="degree"><optgroup class="option2" label="Degrees">';
        while ($row = mysqli_fetch_array($result)) {
            $id = $row["DegreeID"];
            $name = $row["Degree"];
            if (isset($did) && !empty($did) && $did == $id && $dname == $name && $isInRegisterThesis == 1) {echo '<option class="option2" value="'.$id.'" selected>'.$name.'</option>';}
            else {echo '<option class="option2" value="'.$id.'">'.$name.'</option>';}
        }
        echo '</optgroup></select>';
    }
    else {
        echo '<select name="degree" class="selector"><optgroup class="option2" label="Degrees">';
        echo '<option class="option2" value="none">Empty degree</option>';
        echo '</optgroup></select>';
    }
}

// Close connection
$conn->close();
?>