<html>

<head>
    <?php include 'head.php';?>
</head>

<body>

<div class="search_container">
    <?php include 'title.php';?>
    <form action="login.php" method="POST" class="search_form">
        <input type="text" name="uname" placeholder="Username" class="input_bg"/>
        <input type="text" name="pass" placeholder="Password" class="input_bg"/>
        <input type="submit" title="Login" value="Login" class="input_btn"/>
    </form>
</div>

<?php include 'upperlinks.php';?>
<?php include 'footer.php';?>

</body>

</html>
