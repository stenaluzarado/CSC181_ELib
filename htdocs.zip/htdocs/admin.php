<html>

<head>
    <?php include 'head.php';?>
</head>

<body>

    <form id="login" action="login.php" method="POST">
        <table cellspacing="30" cellpadding="0" border="0" class="login_container">
        <tr>
        <td><input type="text" name="uname" placeholder="Username" class="input_bg" id="uname"/></td>
        </tr>
        <tr>
        <td><input type="password" name="pass" placeholder="Password" class="input_bg" id="pass"/></td>
        </tr>
        <tr>
        <td><input type="submit" title="Login" value="Login" class="input_btn"/></td>
        </tr>
        </table>
    </form>

<?php include 'upperlinks.php';?>
<?php include 'footer.php';?>

</body>

</html>
