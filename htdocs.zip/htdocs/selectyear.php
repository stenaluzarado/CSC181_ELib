<?php

echo '<select name="pubyear" class="selector" id="pubyear">
      <optgroup class="option2" label="Years">';
      $yr = 1900;
      $cyr = date("Y");
      while ($yr <= $cyr) {
          if (isset($pubyear) && !empty($pubyear) && $pubyear == $yr && $isInRegisterThesis == 1) {echo '<option class="option2" value="'.$yr.'" selected>'.$yr.'</option>';}
          else {echo '<option class="option2" value="'.$yr.'">'.$yr.'</option>';}
          $yr++;
      }
echo '</optgroup></select>';

?>