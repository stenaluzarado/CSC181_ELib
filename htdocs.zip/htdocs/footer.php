<div id="dialog" class="modal">
    <div class="modal-content">
        <p id="dialogMessage">Message here.</p>
    </div>
</div>

<?php

if (isset($_SESSION['notif'])) {
    $notif = $_SESSION['notif'];
    if ($notif == 'slogin') {
        echo '<script>showDialog("Logged in successfully");</script>';
    }
    else if ($notif == 'elogin') {
        echo '<script>showDialog("Invalid account!");</script>';
    }
    else if ($notif == 'logout') {
        echo '<script>showDialog("Logged out successfully");</script>';
    }
    else if ($notif == 'sadd') {
        echo '<script>showDialog("Added successfully");</script>';
    }
    else if ($notif == 'eadd') {
        echo '<script>showDialog("Error adding");</script>';
    }
    else if ($notif == 'accessdenied') {
        echo '<script>showDialog("Access denied!");</script>';
    }
    else if ($notif == 'exist') {
        echo '<script>showDialog("Query exists!");</script>';
    }
    $_SESSION['notif'] = '';
}

?>