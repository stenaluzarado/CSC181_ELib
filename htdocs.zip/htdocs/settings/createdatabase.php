<?php
// Include variables
include '../variables.php';

// Create connection
$conn = new mysqli($servername, $username, $password);

// SQL Command
$sql = "CREATE DATABASE `$dbname`";

// Check connection
if ($conn->connect_error) {
    die("Connection failed");
}

// Run
$result = $conn->query($sql);
if ($result) {
   echo "Database created successfully.";
}
else {
   echo "Error creating database.";
}

// Close connection
$conn->close();
?>
