<?php
// Include variables
include '../variables.php';

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {die("Connection failed");}

// SQL Command to create database
$sqlCreateDatabase = "CREATE DATABASE IF NOT EXISTS `$dbname`";

// Run
$resultCreateDatabase = $conn->query($sqlCreateDatabase);

if ($resultCreateDatabase) {
    echo "<br>Database - Good. Do not worry if you have an existing database.";

    // Fetch results to clear the command buffer
    while ($conn->more_results()) {$conn->next_result(); $conn->use_result();}

    // Select the database
    $conn->select_db($dbname);

    // Include the code for creating tables
    include ('tables.php');

    // Escape and encrypt
    $uname = mysqli_real_escape_string($conn, $clientName);
    $pass = mysqli_real_escape_string($conn, $clientPass);

    include '../encrypt.php';
    $pass = epass($pass, $uname);

    // SQL Command to add admin user
    $sqlAddAdmin = "INSERT INTO `$admintable` (Username, Password) VALUES ('$uname', '$pass')";

    // Run
    $resultAddAdmin = $conn->query($sqlAddAdmin);

    if ($resultAddAdmin) {
        echo '<br>Admin added successfully.';
        // Fetch results to clear the command buffer
        while ($conn->more_results()) {$conn->next_result(); $conn->use_result();}
    }
    else {echo '<br>Error adding admin: '.$conn->error;}
}
else {echo "<br>Error creating database: ".$conn->error;}

// Close connection
$conn->close();
?>
