<?php

// SQL Command
$sql = "
    CREATE TABLE IF NOT EXISTS `$admintable` (
        `AdminID` INT(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
        `Username` VARCHAR(255) DEFAULT '' NOT NULL,
        `Password` VARCHAR(255) DEFAULT '' NOT NULL
    ) DEFAULT CHARACTER SET utf8;

    CREATE TABLE IF NOT EXISTS `$thesistable` (
        `ThesisID` INT(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
        `ProgramID` VARCHAR(255) DEFAULT '' NOT NULL,
        `DegreeID` VARCHAR(255) DEFAULT '' NOT NULL,
        `Title` VARCHAR(255) DEFAULT '' NOT NULL,
        `PublicationYear` VARCHAR(255) DEFAULT '' NOT NULL,
        `Abstract` VARCHAR(2000) DEFAULT '' NOT NULL
    ) DEFAULT CHARACTER SET utf8;

    CREATE TABLE IF NOT EXISTS `$programtable` (
        `ProgramID` VARCHAR(255) DEFAULT '' NOT NULL,
        `Program` VARCHAR(255) DEFAULT '' NOT NULL
    ) DEFAULT CHARACTER SET utf8;

    CREATE TABLE IF NOT EXISTS `$degreetable` (
        `DegreeID` VARCHAR(255) DEFAULT '' NOT NULL,
        `Degree` VARCHAR(255) DEFAULT '' NOT NULL
    ) DEFAULT CHARACTER SET utf8;

    CREATE TABLE IF NOT EXISTS `$authortable` (
        `AuthorID` INT(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
        `Firstname` VARCHAR(255) DEFAULT '' NOT NULL,
        `Surname` VARCHAR(255) DEFAULT '' NOT NULL
    ) DEFAULT CHARACTER SET utf8;

    CREATE TABLE IF NOT EXISTS `$thesisauthortable` (
        `ThesisID` VARCHAR(255) DEFAULT '' NOT NULL,
        `AuthorID` VARCHAR(255) DEFAULT '' NOT NULL
    ) DEFAULT CHARACTER SET utf8;
";

// Run
if ($conn->multi_query($sql)) {
    echo "<br>Tables - Good. Do not worry if you have an existing tables.";
    // Fetch results to clear the command buffer
    while ($conn->more_results()) {$conn->next_result(); $conn->use_result();}
}
else {echo "<br>Error creating tables: ".$conn->error;}

?>
