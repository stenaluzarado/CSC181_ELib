<?php

if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {

    // Include variables
    include 'variables.php';

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // SQL Command
    $sql = "SELECT ThesisID FROM `$thesistable`";

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed");
    }

    // Run
    $result = $conn->query($sql);
    if ($result) {
        $number_of_result = mysqli_num_rows($result);  
        if ($number_of_result > 0) {

            $results_per_page = 10;
            $number_of_page = ceil($number_of_result/$results_per_page);
            if (!empty($_GET['page'])) {$page = $_GET['page'];}
            else {$page = 1;}

            // To understand the limit part $offset is where the selection starts then comma, then the limit.
            $offset = ($page-1)*$results_per_page;
            $sql = "SELECT $thesistable.*, $programtable.*, $degreetable.*
                FROM `$thesistable`
                JOIN $programtable ON $thesistable.ProgramID = $programtable.ProgramID
                JOIN $degreetable ON $thesistable.DegreeID = $degreetable.DegreeID
                ORDER BY ThesisID DESC LIMIT ".$offset.",".$results_per_page;
            $result = $conn->query($sql);

            echo '<tr><td class="tableheader" style="border-radius:20px 0 0 0;" width="40%">Title</td><td class="tableheader">Author</td><td class="tableheader">Publication Year</td><td class="tableheader">Program</td><td class="tableheader" style="border-radius:0 20px 0 0;">Degree</td></tr>';

            while ($row = mysqli_fetch_array($result)) {
                $tid = $row["ThesisID"];
                $title = $row["Title"];

                $author = "";
                $sq = "SELECT * FROM `$thesisauthortable` WHERE ThesisID='$tid'";
                $res = $conn->query($sq);
                while ($r = mysqli_fetch_array($res)) {
                    $aid = $r['AuthorID'];
                    $sqx = "SELECT * FROM `$authortable` WHERE AuthorID='$aid'";
                    $resx = $conn->query($sqx);
                    $r = mysqli_fetch_array($resx);
                    $author .= $r['Surname'].", ".$r['Firstname']."<br>";
                }

                $pubyear = $row["PublicationYear"];
                $pid = $row["ProgramID"];
                $pname = $row["Program"];
                $did = $row["DegreeID"];
                $dname = $row["Degree"];
                echo '<tr valign="top" title="Click to perform actions" onclick="fetchthesisdata(\''.$tid.'\')"><td class="cells">'.$title.'</td><td class="cells">'.trim($author).'</td><td class="cells" align="center">'.$pubyear.'</td><td class="cells" title="'.$pname.'" align="center">'.$pid.'</td><td class="cells" title="'.$dname.'" align="center">'.$did.'</td></tr>';
            }

            echo '<tr><td colspan="5">';
                if ($result && $number_of_result > 0) {
                    echo "<div class='paginationholder'><span style='margin-right:10px;float:left;color:#a78262;font-weight:bold;'>No. of pages ".$number_of_page."</span>";

                    $number_of_pages_in_pagination = 5;
                    $start = 1;
                    $end = $number_of_pages_in_pagination;
		    if (isset($_GET['pagestart']) && isset($_GET['pageend'])) {
                        $start = $_GET['pagestart'];
                        $end = $_GET['pageend'];
		    }
                    if (empty($start) || empty($end) || $start >= $end ) {$start = 1; $end = $number_of_pages_in_pagination;}
                    if ($page > $end) {$start = $page-($number_of_pages_in_pagination-1); $end = $page;}
                    if ($page < $start) {$start = $page; $end = $page+($number_of_pages_in_pagination-1);}
                    if ($number_of_page < $number_of_pages_in_pagination) {$end = $number_of_page;}

                    $prev = $page-1;
                    if ($prev > 0) {echo "<a class='pagination' href='dashboard.php?page=".$prev."&pagestart=".$start."&pageend=".$end."'>Prev</a>";}
                    for ($p=$start; $p<=$end; $p++) {
                        if ($page == $p) {echo "<a class='currentpagination' href='dashboard.php?page=".$p."&pagestart=".$start."&pageend=".$end."'>".$p."</a>";}
                        else {echo "<a class='pagination' href='dashboard.php?page=".$p."&pagestart=".$start."&pageend=".$end."'>".$p."</a>";}
                    }
                    $next = $page+1;
                    if ($next <= $number_of_page) {echo "<a class='pagination' href='dashboard.php?page=".$next."&pagestart=".$start."&pageend=".$end."'>Next</a>";}
                    echo "</div>";
                }
            echo '</td></tr>';

            mysqli_free_result($result);
        }
        else {echo '<tr><td>No thesis in the database.</td></tr>';}
    }

    // Close connection
    $conn->close();

}

?>