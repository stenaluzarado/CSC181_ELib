<?php

session_start();

if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
    if (!isset($_POST['title']) || empty($_POST['title']) || !isset($_POST['degree']) || empty($_POST['degree']) || !isset($_POST['author']) || empty($_POST['author']) || !isset($_POST['program']) || empty($_POST['program']) || !isset($_POST['abstract']) || empty($_POST['abstract']) || !isset($_POST['pubyear']) || empty($_POST['pubyear'])) {
        $_SESSION['notif'] = 'eadd';
        header("Location: dashboard.php");
        exit();
    }

    include 'variables.php';

    $title = $_POST['title'];
    $author = $_POST['author'];
    $degreeid = $_POST['degree'];
    $programid = $_POST['program'];
    $pubyear = $_POST['pubyear'];
    $abstract = $_POST['abstract'];

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    $title = mysqli_real_escape_string($conn, $title);
    $author = mysqli_real_escape_string($conn, $author);
    $degreeid = mysqli_real_escape_string($conn, $degreeid);
    $programid = mysqli_real_escape_string($conn, $programid);
    $pubyear = mysqli_real_escape_string($conn, $pubyear);
    $abstract = mysqli_real_escape_string($conn, $abstract);

    // SQL Command
    $sql = "SELECT * FROM `$authortable` WHERE CONCAT(Firstname, ' ', Surname)='$author' OR CONCAT(Surname, ' ', Firstname)='$author'";
    $sql2 = "INSERT INTO `$thesistable` (ProgramID, DegreeID, Title, PublicationYear, Abstract) VALUES ('$programid', '$degreeid', '$title', '$pubyear', '$abstract')";

    $a = explode(" ", $author);
    if (count($a) != 2) {
        $_SESSION['notif'] = 'eadd';
        header("Location: dashboard.php");
        exit();
    }
    $sql3 = "INSERT INTO `$authortable` (Firstname, Surname) VALUES ('$a[0]', '$a[1]')";

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed");
    }

    // Run
    $result = $conn->query($sql);
    if ($result) {
        $number_of_result = mysqli_num_rows($result);  
        if ($number_of_result == 0) {
            $result2 = $conn->query($sql2);
            if ($result2) {
                $lastThesisID = $conn->insert_id;
                $result3 = $conn->query($sql3);
                if ($result3) {
                    $lastAuthorID = $conn->insert_id;
                    $sql4 = "INSERT INTO `$thesisauthortable` (ThesisID, AuthorID) VALUES ('$lastThesisID', '$lastAuthorID')";
                    $result4 = $conn->query($sql4);
                    if ($result4) {$_SESSION['notif'] = 'sadd';}
                    else {$_SESSION['notif'] = 'eadd';}
                }
                else {$_SESSION['notif'] = 'eadd';}
            }
            else {$_SESSION['notif'] = 'eadd';}
        }
        else {
            $row = mysqli_fetch_array($result);
            $authorID = $row['AuthorID'];
            $nsql = "SELECT * FROM `$thesisauthortable` WHERE AuthorID='$authorID'";
            $nresult = $conn->query($nsql);
            if ($nresult) {
                $c = 0;
                while ($r = mysqli_fetch_array($nresult)) {
                    $thesisID = $r['ThesisID'];
                    $nsql2 = "SELECT * FROM `$thesistable` WHERE ThesisID='$thesisID'";
                    $nresult2 = $conn->query($nsql2);
                    if ($nresult2) {
                        $r2 = mysqli_fetch_array($nresult2);
                        $title1 = $r2['Title'];
                        $pubyear1 = $r2['PublicationYear'];
                        if ($title1 == $title && $pubyear1 == $pubyear) {$c++; break;}
                    }
                }
                if ($c == 0) {
                    $nsql3 = "INSERT INTO `$thesistable` (ProgramID, DegreeID, Title, PublicationYear, Abstract) VALUES ('$programid', '$degreeid', '$title', '$pubyear', '$abstract')";
                    $nresult3 = $conn->query($nsql3);
                    if ($nresult3) {
                        $lastThesisID = $conn->insert_id;
                        $nsql4 = "INSERT INTO `$thesisauthortable` (ThesisID, AuthorID) VALUES ('$lastThesisID', '$authorID')";
                        $nresult4 = $conn->query($nsql4);
                        if ($nresult4) {$_SESSION['notif'] = 'sadd';}
                        else {$_SESSION['notif'] = 'eadd';}
                    }
                    else {$_SESSION['notif'] = 'eadd';}
                }
                else {$_SESSION['notif'] = 'exist';}
            }
            else {$_SESSION['notif'] = 'eadd';}
        }
    }
    else {$_SESSION['notif'] = 'eadd';}
    header("Location: dashboard.php");
    exit();

    // Close connection
    $conn->close();
}
else {
    $_SESSION['notif'] = 'accessdenied';
    header("Location: index.php");
    exit();
}

?>