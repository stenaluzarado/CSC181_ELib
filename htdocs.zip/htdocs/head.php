<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>DMS Mini Thesis Library</title>
<link rel="icon" type="image/x-icon" href="images/favicon.ico">

<?php

function isMobile() {
    $userAgent = $_SERVER['HTTP_USER_AGENT'];
    $words = ['mobile', 'android', 'iphone', 'ipad', 'phone'];
    foreach ($words as $keyword) {
        if (stripos($userAgent, $keyword) !== false) {return true;}
    }
    return false;
}

if (isMobile()) {
    echo '<link rel="stylesheet" href="css/style_m.css">';
}
else {
    echo '<link rel="stylesheet" href="css/style.css">';
}

session_start();

?>