<title>DMS Mini Thesis Library</title>
<link rel="stylesheet" href="css/style.css">
<link rel="icon" type="image/x-icon" href="images/favicon.ico">

<script type="text/javascript">
    function showDialog(Message) {
        var dialog = document.getElementById("dialog");
        var dialogMessage = document.getElementById("dialogMessage");
        dialogMessage.innerHTML = Message;
        dialog.style.display = "block";
    }

    window.onclick = function(event) {
        var dialog = document.getElementById("dialog");
        if (event.target == dialog) {
            dialog.style.display = "none";
        }
    }
</script>

<?php session_start();?>