<html>

<head>
    <?php include 'head.php';?>
</head>

<body>

<?php

if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
    if (isset($_GET['dpage']) && $_GET['dpage'] == 'addadmin') {
        echo '
          <form action="addadmin.php" method="POST" class="add_form">
              <table cellpadding="0" cellspacing="20" border="0" class="add_stable">
              <tr>
              <td>
                  <p class="bigtitle">Admin Registration</p>
              </td>
              </tr>
              <tr>
              <td align="center"><input type="text" name="uname" placeholder="Username" class="addinput_sbg" style="width:50%;"/></td>
              </tr>
              <tr>
              <td align="center"><input type="text" name="pass" placeholder="Password" class="addinput_sbg" style="width:50%;"/></td>
              </tr>
              <tr>
              <td align="center">
                  <input type="submit" title="Add" value="Register" class="input_btn"/>
                  <input type="hidden" name="re" value="addadmin"/>
              </td>
              </tr>
              </table>
          </form>
        ';
    }
    else if (isset($_GET['dpage']) && $_GET['dpage'] == 'addprogram') {
        echo '
          <form action="addprogram.php" method="POST" class="add_form">
              <table cellpadding="0" cellspacing="20" border="0" class="add_stable">
              <tr>
              <td>
                  <p class="bigtitle">Register Program</p>
              </td>
              </tr>
              <tr>
              <td align="center"><input type="text" name="pid" placeholder="Program ID" class="addinput_sbg" style="width:50%;"/></td>
              </tr>
              <tr>
              <td align="center"><input type="text" name="pname" placeholder="Program" class="addinput_sbg" style="width:50%;"/></td>
              </tr>
              <tr>
              <td align="center">
                  <input type="submit" title="Add" value="Register" class="input_btn"/>
                  <input type="hidden" name="re" value="addprogram"/>
              </td>
              </tr>
              </table>
          </form>
        ';
    }
    else if (isset($_GET['dpage']) && $_GET['dpage'] == 'adddegree') {
        echo '
          <form action="adddegree.php" method="POST" class="add_form">
              <table cellpadding="0" cellspacing="20" border="0" class="add_stable">
              <tr>
              <td>
                  <p class="bigtitle">Register Degree</p>
              </td>
              </tr>
              <tr>
              <td align="center"><input type="text" name="did" placeholder="Degree ID" class="addinput_sbg" style="width:50%;"/></td>
              </tr>
              <tr>
              <td align="center"><input type="text" name="dname" placeholder="Degree" class="addinput_sbg" style="width:50%;"/></td>
              </tr>
              <tr>
              <td align="center">
                  <input type="submit" title="Add" value="Register" class="input_btn"/>
                  <input type="hidden" name="re" value="adddegree"/>
              </td>
              </tr>
              </table>
          </form>
        ';
    }
    else {
        echo '
        <tr>
        <td>
            <p class="bigtitle">DMS Mini Thesis Library</p>
        </td>
        </tr>
          <form action="addthesis.php" method="POST" class="add_form">
              <table cellpadding="0" cellspacing="20" border="0" class="add_table">
              <tr>
              <td width="68%"><input type="text" name="title" placeholder="Title" class="addinput_bg"/></td>
              </tr>
              <tr>
              <td><input type="text" name="author" placeholder="Author" class="addinput_bg"/></td>
              </tr>
              <tr>
              <td>'; include 'selectdegree.php'; echo '</td>
              </tr>
              <tr>
              <td>'; include 'selectprogram.php'; echo '</td>
              </tr>
              <tr valign="top">
              <td><textarea name="abstract" placeholder="Abstract" class="addtextarea_bg" rows="10"></textarea></td>
              </tr>
              <tr>
              <td><input type="text" name="pubyear" placeholder="Publication Year" class="addinput_bg"/></td>
              </tr>
              <tr>
              <td align="right">
                  <input type="submit" title="Add" value="Register" class="input_btn"/>
              </td>
              </tr>
              </table>
          </form>
        ';
    }

    echo '<div class="dashboard_side_table">';
    echo '<table width="100%" cellpadding="0" cellspacing="0" border="0">
              <tr>
              <td align="left"><br><a href="dashboard.php" class="dashboard_side_links">Add Thesis</a><br><br><br>
                  <a href="dashboard.php?dpage=addadmin" class="dashboard_side_links">Add Admin</a><br><br><br>
                  <a href="dashboard.php?dpage=addprogram" class="dashboard_side_links">Add Program</a><br><br><br>
                  <a href="dashboard.php?dpage=adddegree" class="dashboard_side_links">Add Degree</a>
              </td>
              </tr>
              <tr>
              <td valign="top" style="padding:40px 20px 20px 20px;">';
                  if (isset($_SESSION['name'])) {echo 'Welcome back '.$_SESSION['name'].'.';}
                  include 'variables.php';
                  $conn = new mysqli($servername, $username, $password, $dbname);
                  if ($conn->connect_error) {}
                  else {
                      $sql = "SELECT ThesisID FROM `$thesistable`";
                      $r = $conn->query($sql);
                      if ($r) {$n = mysqli_num_rows($r); echo '<br><br>Total thesis: '.$n;}

                      $sql = "SELECT AuthorID FROM `$authortable`";
                      $r = $conn->query($sql);
                      if ($r) {$n = mysqli_num_rows($r); echo '<br>Total author: '.$n;}

                      $sql = "SELECT DegreeID FROM `$degreetable`";
                      $r = $conn->query($sql);
                      if ($r) {$n = mysqli_num_rows($r); echo '<br>Total degree: '.$n;}

                      $sql = "SELECT ProgramID FROM `$programtable`";
                      $r = $conn->query($sql);
                      if ($r) {$n = mysqli_num_rows($r); echo '<br>Total program: '.$n;}

                      $sql = "SELECT AdminID FROM `$admintable`";
                      $r = $conn->query($sql);
                      if ($r) {$n = mysqli_num_rows($r); echo '<br>Total admin: '.$n;}

                  }

              echo '</td>
              </tr>
          </table>';
    echo '</div>';
}
else {
    $_SESSION['notif'] = 'accessdenied';
    header("Location: index.php");
    exit();
}

include 'upperlinks.php';

?>

<?php include 'footer.php';?>

</body>

</html>
