<?php

// Admin server login info
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "thesis";
$admintable = "admin";
$thesistable = "thesis";
$thesisauthortable = "thesis_author";
$authortable = "author";
$programtable = "program";
$degreetable = "degree";

// Client default admin
$clientName = 'ReyCuenca';
$clientPass = 'DMS123';

?>
