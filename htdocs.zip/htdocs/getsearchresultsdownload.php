<?php

// Make sure zip is enabled in php.ini ;extension=zip remove the semicolon
// Located in c/xampp/php/php.ini

if (!isset($_GET['s']) || empty($_GET['s'])) {exit();}
else {
    include 'variables.php';

    $s = trim($_GET['s']);
    $d = '';
    $p = '';
    if (isset($_GET['d']) && !empty($_GET['d'])) {$d = trim($_GET['d']);}
    if (isset($_GET['p']) && !empty($_GET['p'])) {$p = trim($_GET['p']);}

    $a = explode(" ", $d);
    $b = explode(" ", $p);

    $conditions = array();
    if (!empty($a) && (count($a) > 1 || !empty($a[0]))) {
        foreach ($a as $degree) {
            if (!empty($degree)) {
                if (!empty($b) && (count($b) > 1 || !empty($b[0]))) {
                    foreach ($b as $program) {
                        if (!empty($program)) {
                            $conditions[] = "$thesistable.DegreeID='$degree' AND $thesistable.ProgramID='$program'";
                        }
                    }
                }
                else {
                    $conditions[] = "$thesistable.DegreeID='$degree'";
                }
            }
        }
    }
    elseif (!empty($b) && (count($b) > 1 || !empty($b[0]))) {
        foreach ($b as $program) {
            if (!empty($program)) {
                $conditions[] = "$thesistable.ProgramID='$program'";
            }
        }
    }
    $conditions_str = implode(' OR ', $conditions);
    if (!empty($conditions_str)) {
        $conditions_str = "AND ($conditions_str)";
    }

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    $s = mysqli_real_escape_string($conn, $s);

    // SQL Command
    $sql = "SELECT * FROM `$thesistable` WHERE Abstract LIKE '%$s%' $conditions_str OR Title LIKE '%$s%' $conditions_str";

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed");
    }

    // Run
    $result = $conn->query($sql);
    if ($result) {
        $number_of_result = mysqli_num_rows($result);  
        if ($number_of_result > 0) {
            $totalRows = 4;
            $totalCells = 7;
            $data1 = '';
            $data2 = '';
            $srow = 5;
            $indexs = 7;
            $a = ['A', 'B', 'C', 'D', 'E', 'F'];
            $sql = "SELECT $thesistable.*, $programtable.*, $degreetable.*
                FROM `$thesistable`
                JOIN $programtable ON $thesistable.ProgramID = $programtable.ProgramID
                JOIN $degreetable ON $thesistable.DegreeID = $degreetable.DegreeID
                WHERE $thesistable.Abstract LIKE '%$s%' $conditions_str OR $thesistable.Title LIKE '%$s%' $conditions_str
                ORDER BY ThesisID";
            $result = $conn->query($sql);
            $results = [];
            while ($row = $result->fetch_assoc()) {$results[] = $row;}
            usort($results, function($a, $b) use ($s) {
                $counta = substr_count(strtolower($a["Title"].' '.$a["Abstract"]), strtolower($s));
                $countb = substr_count(strtolower($b["Title"].' '.$b["Abstract"]), strtolower($s));
                return $countb-$counta;
            });
            foreach ($results as $row) {
                $tid = $row["ThesisID"];
                $title = $row["Title"];

                $author = "";
                $sq = "SELECT * FROM `$thesisauthortable` WHERE ThesisID='$tid'";
                $res = $conn->query($sq);
                while ($r = mysqli_fetch_array($res)) {
                    $aid = $r['AuthorID'];
                    $sqx = "SELECT * FROM `$authortable` WHERE AuthorID='$aid'";
                    $resx = $conn->query($sqx);
                    $r = mysqli_fetch_array($resx);
                    $author .= $r['Surname'].", ".$r['Firstname']."\n";
                }

                $pubyear = $row["PublicationYear"];
                $pid = $row["ProgramID"];
                $pname = $row["Program"];
                $did = $row["DegreeID"];
                $dname = $row["Degree"];
                $abstract = $row["Abstract"];
                $count = substr_count(strtolower($title.' '.$abstract), strtolower($s));
                $data1 .= '<si><t>'.$count.'</t></si><si><t>'.$title.'</t></si><si><t>'.trim($author).'</t></si><si><t>'.$pubyear.'</t></si><si><t>'.$pid.'</t></si><si><t>'.$did.'</t></si>';
                $data2 .= '<row r="'.$srow.'" spans="1:6" x14ac:dyDescent="0.2">';
                $cnn = 1;
                foreach ($a as $c) {
                    if ($cnn == 1 || $cnn == 4 || $cnn == 5 || $cnn == 6) {$data2 .= '<c r="'.$c.$srow.'" s="12" t="s"><v>'.$indexs.'</v></c>';}
                    else {$data2 .= '<c r="'.$c.$srow.'" s="13" t="s"><v>'.$indexs.'</v></c>';}
                    $indexs++;
                    $cnn++;
                }
                $data2 .= '</row>';
                $totalCells = $totalCells+6;
                $totalRows++;
                $srow++;
            }
            mysqli_free_result($result);

            $xlsx = new ZipArchive();
            $xlsxFilename = 'DMSThesis.xlsx';
            $srcFolder = $_SERVER['DOCUMENT_ROOT'].'/excel';
            if ($xlsx->open($xlsxFilename, ZipArchive::CREATE | ZipArchive::OVERWRITE) === TRUE) {
                $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($srcFolder, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::SELF_FIRST);
                foreach ($files as $name => $file) {
                    $relativePath = str_replace('\\', '/', substr($file->getPathname(), strlen($srcFolder) + 1));
                    if ($file->isDir()) {$xlsx->addEmptyDir($relativePath);}
                    else {
                        if ($file->getFilename() === 'sharedStrings.xml') {
                            $contents = file_get_contents($file->getPathname());
                            $contents = str_replace('TOTAL_COUNT_OF_CELLS', $totalCells, $contents);
                            $contents = str_replace('INSERT_DATA_HERE', $data1, $contents);
                            $xlsx->addFromString($relativePath, $contents);
                        }
                        else if ($file->getFilename() === 'sheet1.xml') {
                            $contents = file_get_contents($file->getPathname());
                            $contents = str_replace('TOTAL_ROWS', $totalRows, $contents);
                            $contents = str_replace('INSERT_DATA_HERE', $data2, $contents);
                            $xlsx->addFromString($relativePath, $contents);
                        }
                        else {$xlsx->addFile($file->getPathname(), $relativePath);}
                    }
                }
                $xlsx->close();
                header('Content-Type:application/xlsx');
                header('Content-Disposition:attachment;filename='.$xlsxFilename);
                header('Content-Length:'.filesize($xlsxFilename));
                readfile($xlsxFilename);
                unlink($xlsxFilename);
                exit;
            }
            else {echo 'Failed to download excel file.';}

        }
        else {echo 'No results found.';}
    }

    // Close connection
    $conn->close();
}

?>