<?php

session_start();

if (!isset($_POST['uname']) || empty($_POST['uname']) || !isset($_POST['pass']) || empty($_POST['pass'])) {echo 'Error login!'; exit();}

include 'variables.php';

// Get variables
$uname = trim($_POST['uname']);
$pass = trim($_POST['pass']);

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

$uname = mysqli_real_escape_string($conn, $uname);
$pass = mysqli_real_escape_string($conn, $pass);

include 'encrypt.php';
$pass = epass($pass, $uname);

// SQL Command
$sql = "SELECT * FROM `$admintable` WHERE BINARY Username='$uname' AND BINARY Password='$pass' LIMIT 1";

// Check connection
if ($conn->connect_error) {
    die("Connection failed");
}

// Run
$result = $conn->query($sql);
if ($result) {
    $number_of_result = mysqli_num_rows($result);  
    if ($number_of_result == 1) {
        $row = mysqli_fetch_array($result);
        $_SESSION['role'] = 'admin';
        $_SESSION['name'] = $row["Username"];
        echo 'Success';
    }
    else {echo 'Incorrect login details!';}
}
else {echo 'Error login!';}

// Close connection
$conn->close();
?>
