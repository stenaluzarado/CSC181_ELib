<?php
    if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
        echo '<a href="logout.php" class="upperlinks" style="margin-right:50px;" id="logout_upperlink">Logout</a>';
        echo '<a href="dashboard.php" class="upperlinks" style="margin-right:180px;" id="dashboard_upperlink">Dashboard</a>';
        echo '<a href="index.php" class="upperlinks" style="margin-right:345px;" id="admin_home_upperlink">Home</a>
              <form id="searchform" method="GET">';
        echo '<table cellspacing="0" cellpadding="0" border="0" id="search_container_upperlink" class="search_container_upperlink" style="margin-right:470px;">
              <tr id="srow">
              <td align="right"><input type="text" id="s" name="s" placeholder="Search by keywords" class="search_bg_upperlink"/></td>
              <td><input type="submit" id="ssubmit" name="submit" value="Go" class="search_btn_upperlink" style="border-radius:0;"/></td>
              <td><input type="button" id="filterbtn" name="filterbtn" value="▼" class="filter_btn_upperlink" onclick="showFilters()"/></td>
              </tr>
              <tr align="right" valign="top"><td colspan="3">';
              include 'selectfilters.php';
        echo '</td></tr></table></form>';
    }
    else {
        echo '<a href="admin.php" class="upperlinks" style="margin-right:50px;" id="login_upperlink">Login</a>';
        echo '<input type="button"  id="contact_upperlink" name="contact" value="Contact" class="upperlinks" style="margin-right:170px;" onclick="showContact()"/>';
        echo '<a href="index.php" class="upperlinks" style="margin-right:315px;" id="home_upperlink">Home</a>
              <form id="searchform" method="GET">';
        echo '<table cellspacing="0" cellpadding="0" border="0" id="search_container_upperlink" class="search_container_upperlink" style="margin-right:445px;">
              <tr id="srow">
              <td align="right"><input type="text" id="s" name="s" placeholder="Search by keywords" class="search_bg_upperlink"/></td>
              <td><input type="submit" id="ssubmit" name="submit" value="Go" class="search_btn_upperlink" style="border-radius:0;"/></td>
              <td><input type="button" id="filterbtn" name="filterbtn" value="▼" class="filter_btn_upperlink" onclick="showFilters()"/></td>
              </tr>
              <tr align="right" valign="top"><td colspan="3">';
              include 'selectfilters.php';
        echo '</td></tr></table></form>';
        echo '<div id="contact_holder" class="contact_holder"><h2>Authorized Personnel</h2><b>Name: </b>Rey R. Cuenca<br><b>Phone: </b><a href="tel:+639079706584">+639079706584</a><br><b>Gmail: </b><a href="mailto:rey.cuenca@g.msuiit.edu.ph">rey.cuenca@g.msuiit.edu.ph</a><br><br>For more information, please approach the authorized personnel.</div>';
    }
?>
