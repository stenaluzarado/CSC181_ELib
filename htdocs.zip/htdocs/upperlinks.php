<?php
    if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
        echo '<a href="logout.php" class="upperlinks" style="margin-right:30px;">Logout</a>';
        echo '<a href="dashboard.php" class="upperlinks" style="margin-right:150px;">Dashboard</a>';
        echo '<a href="index.php" class="upperlinks" style="margin-right:300px;">Home</a>';
    }
    else {
        echo '<a href="admin.php" class="upperlinks" style="margin-right:30px;">Login</a>';
        echo '<a href="index.php" class="upperlinks" style="margin-right:150px;">Home</a>';
    }
?>
