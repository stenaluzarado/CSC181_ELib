<?php

session_start();

if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
    if (!isset($_POST['did']) || empty($_POST['did']) || !isset($_POST['dname']) || empty($_POST['dname'])) {
        $re = $_POST['re'];
        $_SESSION['notif'] = 'eadd';
        header("Location: dashboard.php?dpage=".$re);
        exit();
    }

    include 'variables.php';

    $did = $_POST['did'];
    $dname = $_POST['dname'];
    $re = $_POST['re'];

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    $did = mysqli_real_escape_string($conn, $did);
    $dname = mysqli_real_escape_string($conn, $dname);
    $re = mysqli_real_escape_string($conn, $re);

    // SQL Command
    $sql = "SELECT Degree FROM `$degreetable` WHERE Degree='$dname'";
    $sql2 = "INSERT INTO `$degreetable` (DegreeID, Degree) VALUES ('$did', '$dname')";

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed");
    }

    // Run
    $result = $conn->query($sql);
    if ($result) {
        $number_of_result = mysqli_num_rows($result);  
        if ($number_of_result == 0) {
            $result2 = $conn->query($sql2);
            if ($result2) {$_SESSION['notif'] = 'sadd';}
            else {$_SESSION['notif'] = 'eadd';}
        }
        else {$_SESSION['notif'] = 'exist';}
    }
    else {$_SESSION['notif'] = 'eadd';}
    header("Location: dashboard.php?dpage=".$re);
    exit();

    // Close connection
    $conn->close();
}
else {
    $_SESSION['notif'] = 'accessdenied';
    header("Location: index.php");
    exit();
}

?>