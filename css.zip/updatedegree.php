<?php

session_start();

if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
    if (!isset($_POST['deletedegreeid']) || empty($_POST['deletedegreeid']) || !isset($_POST['did']) || empty($_POST['did']) || !isset($_POST['dname']) || empty($_POST['dname'])) {echo 'Error updating!'; exit();}

    include 'variables.php';

    $delid = trim($_POST['deletedegreeid']);
    $id = trim($_POST['did']);
    $name = trim($_POST['dname']);

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    $delid = mysqli_real_escape_string($conn, $delid);
    $id = mysqli_real_escape_string($conn, $id);
    $name = mysqli_real_escape_string($conn, $name);

    // SQL Command
    $sql = "SELECT * FROM `$degreetable` WHERE DegreeID='$id' OR Degree='$name'";
    $sql2 = "UPDATE `$degreetable`
            SET
            DegreeID = '$id',
            Degree = '$name'
            WHERE DegreeID = '$delid'";
    $sql3 = "UPDATE `$thesistable`
            SET
            DegreeID = '$id'
            WHERE DegreeID = '$delid'";

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed");
    }

    // Run
    $result = $conn->query($sql);
    if ($result) {
        $number_of_result = mysqli_num_rows($result);  
        if ($number_of_result == 0) {
            $result = $conn->query($sql2);
            if ($result) {
                $result = $conn->query($sql3);
                if ($result) {echo 'Success';}
                else {echo 'Error updating!';}
            }
            else {echo 'Error updating!';}
        }
        else {
            if ($delid == $id) {
                $sql = "SELECT * FROM `$degreetable` WHERE Degree='$name'";
                $result = $conn->query($sql);
                if ($result) {
                    $n = mysqli_num_rows($result);  
                    if ($n == 0) {
                        $result = $conn->query($sql2);
                        if ($result) {
                            $result = $conn->query($sql3);
                            if ($result) {echo 'Success';}
                            else {echo 'Error updating!';}
                        }
                        else {echo 'Error updating!';}
                    }
                    else {echo 'Degree exists!';}
                }
                else {echo 'Error updating!';}
            }
            else {echo 'Degree exists!';}
        }
    }
    else {echo 'Error updating!';}

    // Close connection
    $conn->close();
}

?>