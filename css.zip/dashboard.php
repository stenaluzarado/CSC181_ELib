<html>

<head>
    <?php include 'head.php';?>
</head>

<body>

<?php

if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
    echo '<div class="dashboard_side_table">';
    echo '<table width="100%" cellpadding="0" cellspacing="0" border="0">
              <tr>
              <td align="center"><br><br>
                  <a id="rthesisbuttonlink" href="dashboard.php" class="dashboard_side_links">Register Thesis</a><br><br><br>
                  <a id="radminbuttonlink" href="dashboard.php?dpage=addadmin" class="dashboard_side_links">Register Admin</a><br><br><br>
                  <a id="rdegreebuttonlink" href="dashboard.php?dpage=adddegree" class="dashboard_side_links">Register Degree</a><br><br><br>
                  <a id="rprogrambuttonlink" href="dashboard.php?dpage=addprogram" class="dashboard_side_links">Register Program</a><br><br><br>
                  <a id="uauthorbuttonlink" href="dashboard.php?dpage=addauthor" class="dashboard_side_links">Update Author</a>
              </td>
              </tr>
              <tr>
              <td valign="top" style="padding:40px 20px 20px 20px;">'; include 'dashboard_details.php'; echo '</td>
              </tr>
          </table>';
    echo '</div>';

    if (isset($_GET['dpage']) && $_GET['dpage'] == 'addauthor') {
        echo '<a id="bigtitle" href="javascript:void(0);" onclick="location.reload();" class="bigtitle">Mini Thesis Library</a>';
        echo '<table cellpadding="0" cellspacing="20" border="0" width="57%" style="position:absolute;top:100;left:10;"><tr valign="top"><td>';
        echo '<table id="latestthesistable" cellpadding="10" cellspacing="0" border="0">';
            include 'getlatestauthor.php';
        echo '</table></td></tr></table>';

        echo '<form id="addauthor" method="POST" class="add_table">
              <table cellpadding="0" cellspacing="20" border="0" class="add_table">
              <tr>
              <td><input type="text" name="fname" placeholder="Firstname" class="addinput_bg" style="opacity:0.3;" id="fname" onkeydown="moveToNextInput(event, \'sname\', \'sname\')" disabled/></td>
              </tr>
              <tr>
              <td><input type="text" name="sname" placeholder="Surname" class="addinput_bg" style="opacity:0.3;" id="sname" onkeydown="moveToNextInput(event, \'fname\', \'fname\')" disabled/></td>
              </tr>
              <tr>
              <td align="right">
                  <input type="hidden" id="deleteauthorid" value="" name="deleteauthorid"/>
                  <input type="button" id="delete" onclick="confirmDialog(\'deleteauthor\')" title="Delete" value="Delete" class="input_red_btn" style="float:left;display:none;"/>
                  <input type="submit" id="update" title="Update" value="Update" class="input_btn" style="opacity:0.3;" disabled/>
              </td>
              </tr>
              </table>
          </form>
          <script>
              document.getElementById("uauthorbuttonlink").classList.add("dashboard_side_links_current");
          </script>
        ';
    }
    else if (isset($_GET['dpage']) && $_GET['dpage'] == 'addadmin') {
        echo '<a id="bigtitle" href="javascript:void(0);" onclick="location.reload();" class="bigtitle">Mini Thesis Library</a>';
        echo '<table cellpadding="0" cellspacing="20" border="0" width="57%" style="position:absolute;top:100;left:10;"><tr valign="top"><td>';
        echo '<table id="latestthesistable" cellpadding="10" cellspacing="0" border="0">';
            include 'getlatestadmin.php';
        echo '</table></td></tr></table>';

        echo '<form id="addadmin" method="POST" class="add_table">
              <table cellpadding="0" cellspacing="20" border="0" class="add_table">
              <tr>
              <td><input type="text" name="uname" placeholder="Username" class="addinput_bg" id="uname" onkeydown="moveToNextInput(event, \'pass\', \'pass\')"/></td>
              </tr>
              <tr>
              <td><input type="text" name="pass" placeholder="Password" class="addinput_bg" id="pass" onkeydown="moveToNextInput(event, \'uname\', \'uname\')"/></td>
              </tr>
              <tr>
              <td align="right">
                  <input type="hidden" id="deleteadminid" value="" name="deleteadminid"/>
                  <input type="button" id="delete" onclick="confirmDialog(\'deleteadmin\')" title="Delete" value="Delete" class="input_red_btn" style="float:left;display:none;"/>
                  <input type="submit" id="register" title="Register" value="Register" class="input_btn"/>
              </td>
              </tr>
              </table>
          </form>
          <script>
              document.getElementById("radminbuttonlink").classList.add("dashboard_side_links_current");
          </script>
        ';
    }
    else if (isset($_GET['dpage']) && $_GET['dpage'] == 'addprogram') {
        echo '<a id="bigtitle" href="javascript:void(0);" onclick="location.reload();" class="bigtitle">Mini Thesis Library</a>';
        echo '<table cellpadding="0" cellspacing="20" border="0" width="57%" style="position:absolute;top:100;left:10;"><tr valign="top"><td>';
        echo '<table id="latestthesistable" cellpadding="10" cellspacing="0" border="0">';
            include 'getlatestprogram.php';
        echo '</table></td></tr></table>';

        echo '<form id="addprogram" method="POST" class="add_table">
              <table cellpadding="0" cellspacing="20" border="0" class="add_table">
              <tr>
              <td><input type="text" name="pid" placeholder="Program ID" class="addinput_bg" id="pid" onkeydown="moveToNextInput(event, \'pname\', \'pname\')"/></td>
              </tr>
              <tr>
              <td><input type="text" name="pname" placeholder="Program" class="addinput_bg" id="pname" onkeydown="moveToNextInput(event, \'pid\', \'pid\')"/></td>
              </tr>
              <tr>
              <td align="right">
                  <input type="hidden" id="deleteprogramid" value="" name="deleteprogramid"/>
                  <input type="button" id="delete" onclick="confirmDialog(\'deleteprogram\')" title="Delete" value="Delete" class="input_red_btn" style="float:left;display:none;"/>
                  <input type="submit" id="register" title="Register" value="Register" class="input_btn"/>
              </td>
              </tr>
              </table>
          </form>
          <script>
              document.getElementById("rprogrambuttonlink").classList.add("dashboard_side_links_current");
          </script>
        ';
    }
    else if (isset($_GET['dpage']) && $_GET['dpage'] == 'adddegree') {
        echo '<a id="bigtitle" href="javascript:void(0);" onclick="location.reload();" class="bigtitle">Mini Thesis Library</a>';
        echo '<table cellpadding="0" cellspacing="20" border="0" width="57%" style="position:absolute;top:100;left:10;"><tr valign="top"><td>';
        echo '<table id="latestthesistable" cellpadding="10" cellspacing="0" border="0">';
            include 'getlatestdegree.php';
        echo '</table></td></tr></table>';

        echo '<form id="adddegree" method="POST" class="add_table">
              <table cellpadding="0" cellspacing="20" border="0" class="add_table">
              <tr>
              <td><input type="text" name="did" placeholder="Degree ID" class="addinput_bg" id="did" onkeydown="moveToNextInput(event, \'dname\', \'dname\')"/></td>
              </tr>
              <tr>
              <td><input type="text" name="dname" placeholder="Degree" class="addinput_bg" id="dname" onkeydown="moveToNextInput(event, \'did\', \'did\')"/></td>
              </tr>
              <tr>
              <td align="right">
                  <input type="hidden" id="deletedegreeid" value="" name="deletedegreeid"/>
                  <input type="button" id="delete" onclick="confirmDialog(\'deletedegree\')" title="Delete" value="Delete" class="input_red_btn" style="float:left;display:none;"/>
                  <input type="submit" id="register" title="Register" value="Register" class="input_btn"/>
              </td>
              </tr>
              </table>
          </form>
          <script>
              document.getElementById("rdegreebuttonlink").classList.add("dashboard_side_links_current");
          </script>
        ';
    }
    else {
        if (isset($_GET['dpage']) && $_GET['dpage'] == 'updatesearch' && isset($_GET['id']) && !empty($_GET['id'])) {
            $tid = '';
            $title = '';
            $author = '';
            $abstract = '';
            $pubyear = '';
            $pid = '';
            $pname = '';
            $did = '';
            $dname = '';
            echo '<a id="bigtitle" href="javascript:void(0);" onclick="location.reload();" class="bigtitle">Update Thesis</a>';
            echo '<table cellpadding="0" cellspacing="20" border="0" width="57%" style="position:absolute;top:100;left:10;"><tr valign="top"><td>';
            echo '<table id="latestthesistable" cellpadding="10" cellspacing="0" border="0">';
                  include 'getupdatesearch.php';
            echo '</table>';
            echo '</td></tr></table>';
            $authors = str_replace("<br>", "\n", $author);
            echo '
                <form id="addthesis" method="POST" class="add_table">
                    <table cellpadding="0" cellspacing="20" border="0" class="add_table">
                    <tr>
                    <td><textarea type="text" name="title" placeholder="Title" class="addinput_tbg" rows="1" style="overflow-y:hidden;resize:none;" oninput="autoResizeTextarea(this)" id="title" onkeydown="moveToNextInput(event, \'author\', \'pubyear\')">'.$title.'</textarea></td>
                    </tr>
                    <tr>
                    <td><textarea type="text" name="author" placeholder="Author (Surname, Firstname)" class="addinput_tbg" rows="1" style="overflow-y:hidden;resize:none;" oninput="autoResizeTextarea(this)" id="author" onkeydown="moveToNextInput(event, \'degree\', \'title\')">'.trim($authors).'</textarea></td>
                    </tr>
                    <tr>
                    <td>'; include 'selectdegree.php'; echo '</td>
                    </tr>
                    <tr>
                    <td>'; include 'selectprogram.php'; echo '</td>
                    </tr>
                    <tr valign="top">
                    <td><textarea name="abstract" placeholder="Abstract" class="addtextarea_bg" rows="7" style="overflow-y:hidden;" oninput="autoResizeTextarea(this)" id="abstract" onkeydown="moveToNextInput(event, \'pubyear\', \'program\')">'.$abstract.'</textarea></td>
                    </tr>
                    <tr>
                    <td><input type="text" name="pubyear" placeholder="Publication Year" class="addinput_bg" id="pubyear" onkeydown="moveToNextInput(event, \'title\', \'abstract\')" value="'.$pubyear.'"></td>
                    </tr>
                    <tr>
                    <td align="right">
                        <input type="hidden" id="deletethesisid" value="'.$tid.'" name="deletethesisid"/>
                        <input type="button" id="delete" onclick="confirmDialog(\'deletethesis\')" title="Delete" value="Delete" class="input_red_btn" style="float:left;display:none;"/>
                        <input type="submit" id="register" title="Update" value="Update" class="input_btn"/>
                    </td>
                    </tr>
                    </table>
                </form>
            ';
            echo '
              <script>
                  function aRT(tarea) {
                      tarea.style.height = "auto";
                      tarea.style.height = (tarea.scrollHeight)+"px";
                  }
                  aRT(document.getElementById("title"))
                  aRT(document.getElementById("author"))
                  aRT(document.getElementById("abstract"))
                  document.getElementById("delete").style.display = "block";
              </script>
            ';
        }
        else {
            echo '<a id="bigtitle" href="javascript:void(0);" onclick="location.reload();" class="bigtitle">Mini Thesis Library</a>';
            echo '<table cellpadding="0" cellspacing="20" border="0" width="57%" style="position:absolute;top:100;left:10;"><tr valign="top"><td>';
            echo '<table id="latestthesistable" cellpadding="10" cellspacing="0" border="0">';
                  include 'getlatestthesis.php';
            echo '</table>';
            echo '</td></tr></table>';
            echo '
                <form id="addthesis" method="POST" class="add_table">
                    <table cellpadding="0" cellspacing="20" border="0" class="add_table">
                    <tr>
                    <td><textarea type="text" name="title" placeholder="Title" class="addinput_tbg" rows="1" style="overflow-y:hidden;resize:none;" oninput="autoResizeTextarea(this)" id="title" onkeydown="moveToNextInput(event, \'author\', \'pubyear\')"></textarea></td>
                    </tr>
                    <tr>
                    <td><textarea type="text" name="author" placeholder="Author (Surname, Firstname)" class="addinput_tbg" rows="1" style="overflow-y:hidden;resize:none;" oninput="autoResizeTextarea(this)" id="author" onkeydown="moveToNextInput(event, \'degree\', \'title\')"></textarea></td>
                    </tr>
                    <tr>
                    <td>'; include 'selectdegree.php'; echo '</td>
                    </tr>
                    <tr>
                    <td>'; include 'selectprogram.php'; echo '</td>
                    </tr>
                    <tr valign="top">
                    <td><textarea name="abstract" placeholder="Abstract" class="addtextarea_bg" rows="7" style="overflow-y:hidden;" oninput="autoResizeTextarea(this)" id="abstract" onkeydown="moveToNextInput(event, \'pubyear\', \'program\')"></textarea></td>
                    </tr>
                    <tr>
                    <td><input type="text" name="pubyear" placeholder="Publication Year" class="addinput_bg" id="pubyear" onkeydown="moveToNextInput(event, \'title\', \'abstract\')"></td>
                    </tr>
                    <tr>
                    <td align="right">
                        <input type="hidden" id="deletethesisid" value="" name="deletethesisid"/>
                        <input type="button" id="delete" onclick="confirmDialog(\'deletethesis\')" title="Delete" value="Delete" class="input_red_btn" style="float:left;display:none;"/>
                        <input type="submit" id="register" title="Register" value="Register" class="input_btn"/>
                    </td>
                    </tr>
                    </table>
                </form>
            ';
            echo '<script>document.getElementById("rthesisbuttonlink").classList.add("dashboard_side_links_current");</script>';
        }
    }
}

include 'upperlinks.php';

?>

<?php include 'footer.php';?>

</body>

</html>
