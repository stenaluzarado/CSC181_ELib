<?php

session_start();

if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
    if (!isset($_POST['deleteadminid']) || empty($_POST['deleteadminid']) || !isset($_POST['uname']) || empty($_POST['uname']) || !isset($_POST['pass']) || empty($_POST['pass'])) {echo 'Error updating!'; exit();}

    include 'variables.php';

    $delid = trim($_POST['deleteadminid']);
    $uname = trim($_POST['uname']);
    $pass = trim($_POST['pass']);

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    $delid = mysqli_real_escape_string($conn, $delid);
    $uname = mysqli_real_escape_string($conn, $uname);
    $pass = mysqli_real_escape_string($conn, $pass);

    // SQL Command
    $sql = "SELECT * FROM `$admintable` WHERE BINARY Username='$uname'";
    $sql2 = "UPDATE `$admintable`
            SET
            Username = '$uname',
            Password = '$pass'
            WHERE AdminID = '$delid'";

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed");
    }

    // Run
    $result = $conn->query($sql);
    if ($result) {
        $number_of_result = mysqli_num_rows($result);  
        if ($number_of_result == 0) {
            $result = $conn->query($sql2);
            if ($result) {echo 'Success';}
            else {echo 'Error updating!';}
        }
        else {
            $row = mysqli_fetch_array($result);
            if ($delid == $row['AdminID']) {
                $result = $conn->query($sql2);
                if ($result) {echo 'Success';}
                else {echo 'Error updating!';}
            }
            else {echo 'Username exists!';}
        }
    }
    else {echo 'Error updating!';}

    // Close connection
    $conn->close();
}

?>