<?php

if (!isset($_GET['s']) || empty($_GET['s'])) {echo 'No results found.';}
else {
    include 'variables.php';

    $s = trim($_GET['s']);
    $d = '';
    $p = '';
    if (isset($_GET['d']) && !empty($_GET['d'])) {$d = trim($_GET['d']);}
    if (isset($_GET['p']) && !empty($_GET['p'])) {$p = trim($_GET['p']);}

    $a = explode(" ", $d);
    $b = explode(" ", $p);

    $conditions = array();
    if (!empty($a) && (count($a) > 1 || !empty($a[0]))) {
        foreach ($a as $degree) {
            if (!empty($degree)) {
                if (!empty($b) && (count($b) > 1 || !empty($b[0]))) {
                    foreach ($b as $program) {
                        if (!empty($program)) {
                            $conditions[] = "DegreeID='$degree' AND ProgramID='$program'";
                        }
                    }
                }
                else {
                    $conditions[] = "DegreeID='$degree'";
                }
            }
        }
    }
    elseif (!empty($b) && (count($b) > 1 || !empty($b[0]))) {
        foreach ($b as $program) {
            if (!empty($program)) {
                $conditions[] = "ProgramID='$program'";
            }
        }
    }
    $conditions_str = implode(' OR ', $conditions);
    if (!empty($conditions_str)) {
        $conditions_str = "AND ($conditions_str)";
    }

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    $s = mysqli_real_escape_string($conn, $s);

    // SQL Command
    $sql = "SELECT ThesisID FROM `$thesistable` WHERE Abstract LIKE '%$s%' $conditions_str OR Title LIKE '%$s%' $conditions_str";

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed");
    }

    // Run
    $result = $conn->query($sql);
    if ($result) {
        $number_of_result = mysqli_num_rows($result);  
        if ($number_of_result > 0) {
            mysqli_free_result($result);
            echo 'Success';
        }
        else {echo 'No results found.';}
    }

    // Close connection
    $conn->close();
}

?>