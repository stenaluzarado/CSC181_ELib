<?php
// Include variables
include '../variables.php';

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// SQL Command
$sql = "CREATE TABLE `$admintable` (
`AdminID` INT(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
`Username` VARCHAR(255) CHARSET utf8 NOT NULL,
`Password` VARCHAR(255) CHARSET utf8 NOT NULL);";

$sql .= "CREATE TABLE `$thesistable` (
`ThesisID` INT(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
`ProgramID` VARCHAR(255) CHARSET utf8 NOT NULL,
`DegreeID` VARCHAR(255) CHARSET utf8 NOT NULL,
`Title` VARCHAR(255) CHARSET utf8 NOT NULL,
`PublicationYear` VARCHAR(255) CHARSET utf8 NOT NULL,
`Abstract` VARCHAR(2000) CHARSET utf8 NOT NULL);";

$sql .= "CREATE TABLE `$programtable` (
`ProgramID` VARCHAR(255) CHARSET utf8 NOT NULL,
`Program` VARCHAR(255) CHARSET utf8 NOT NULL);";

$sql .= "CREATE TABLE `$degreetable` (
`DegreeID` VARCHAR(255) CHARSET utf8 NOT NULL,
`Degree` VARCHAR(255) CHARSET utf8 NOT NULL);";

$sql .= "CREATE TABLE `$authortable` (
`AuthorID` INT(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
`Firstname` VARCHAR(255) CHARSET utf8 NOT NULL,
`Surname` VARCHAR(255) CHARSET utf8 NOT NULL);";

$sql .= "CREATE TABLE `$thesisauthortable` (
`ThesisID` VARCHAR(255) CHARSET utf8 NOT NULL,
`AuthorID` VARCHAR(255) CHARSET utf8 NOT NULL);";

// Check connection
if ($conn->connect_error) {
    die("Connection failed");
}

// Run
if ($conn->multi_query($sql)) {
    do {
        if ($result = $mysqli->store_result()) {$result->free();}
    }
    while ($mysqli->more_results() && $mysqli->next_result());
    echo "Tables created successfully.";
}
else {
   echo "Error creating tables.";
}

// Close connection
$conn->close();
?>
