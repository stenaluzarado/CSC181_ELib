<?php
// Include variables
include '../variables.php';

// Admin
$uname = 'ReyCuenca';
$pass = 'DMS123';

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

$uname = mysqli_real_escape_string($conn, $uname);
$pass = mysqli_real_escape_string($conn, $pass);

include '../encrypt.php';
$pass = epass($pass);

// SQL Command
$sql = "INSERT INTO `$admintable` (Username, Password) VALUES ('$uname', '$pass')";

// Check connection
if ($conn->connect_error) {
    die("Connection failed");
}

// Run
$result = $conn->query($sql);
if ($result) {
    echo 'Admin added successfully.';
}

// Close connection
$conn->close();
?>