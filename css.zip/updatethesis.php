<?php

session_start();

if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
    if (!isset($_POST['deletethesisid']) || empty($_POST['deletethesisid']) || !isset($_POST['title']) || empty($_POST['title']) || !isset($_POST['degree']) || empty($_POST['degree']) || !isset($_POST['author']) || empty($_POST['author']) || !isset($_POST['program']) || empty($_POST['program']) || !isset($_POST['abstract']) || empty($_POST['abstract']) || !isset($_POST['pubyear']) || empty($_POST['pubyear'])) {echo 'Error updating!'; exit();}

    include 'variables.php';

    $tid = trim($_POST['deletethesisid']);
    $title = trim($_POST['title']);
    $au = trim($_POST['author']);
    $did = trim($_POST['degree']);
    $pid = trim($_POST['program']);
    $pubyear = trim($_POST['pubyear']);
    $abstract = trim($_POST['abstract']);

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    $authors = [];
    $as = explode("\n", $au);
    foreach ($as as $aut) {
        $a = explode(",", $aut);
        if (count($a) < 2) {echo 'Error adding!'; exit();}
        $fn = trim($a[1]);
        $ln = trim($a[0]);
        $fn = mysqli_real_escape_string($conn, $fn);
        $ln = mysqli_real_escape_string($conn, $ln);
        $authors[] = [$ln, $fn];
    }

    $tid = mysqli_real_escape_string($conn, $tid);
    $title = mysqli_real_escape_string($conn, $title);
    $did = mysqli_real_escape_string($conn, $did);
    $pid = mysqli_real_escape_string($conn, $pid);
    $pubyear = mysqli_real_escape_string($conn, $pubyear);
    $abstract = mysqli_real_escape_string($conn, $abstract);

    // SQL Command
    $sql = "UPDATE `$thesistable`
            SET
            ProgramID = '$pid',
            DegreeID = '$did',
            Title = '$title',
            PublicationYear = '$pubyear',
            Abstract = '$abstract'
            WHERE ThesisID = '$tid'";

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed");
    }

    // Run
    $result = $conn->query($sql);
    if ($result) {
        $sql = "DELETE FROM `$thesisauthortable` WHERE ThesisID='$tid'";
        $result = $conn->query($sql);
        if (!$result) {echo 'Error updating!'; exit();}
        foreach ($authors as $a) {
            $sql = "SELECT AuthorID FROM `$authortable` WHERE Firstname='$a[1]' AND Surname='$a[0]' OR Firstname='$a[0]' AND Surname='$a[1]'";
            $result = $conn->query($sql);
            if ($result && mysqli_num_rows($result) == 0) {
                $sql = "INSERT INTO `$authortable` (Firstname, Surname) VALUES ('$a[1]', '$a[0]')";
                $result = $conn->query($sql);
                if ($result) {
                    $lastAuthorID = $conn->insert_id;
                    $sql = "INSERT INTO `$thesisauthortable` (ThesisID, AuthorID) VALUES ('$tid', '$lastAuthorID')";
                    if ($conn->query($sql) !== TRUE) {echo 'Error updating!'; exit();}
                }
                else {echo 'Error updating!'; exit();}
            }
            else {
                $r = mysqli_fetch_array($result);
                $aid = $r['AuthorID'];
                $sql = "SELECT AuthorID FROM `$thesisauthortable` WHERE ThesisID='$tid' AND AuthorID='$aid'";
                $result = $conn->query($sql);
                if ($result && mysqli_num_rows($result) == 0) {
                    $sql = "INSERT INTO `$thesisauthortable` (ThesisID, AuthorID) VALUES ('$tid', '$aid')";
                    if ($conn->query($sql) !== TRUE) {echo 'Error updating!'; exit();}
                }
            }
        }
        $sql = "DELETE FROM `$authortable` WHERE NOT EXISTS (SELECT 1 FROM `$thesisauthortable` WHERE $thesisauthortable.AuthorID = $authortable.AuthorID)";
        $result = $conn->query($sql);
        if ($result) {echo 'Success';}
        else {echo 'Error updating!';}
    }
    else {echo 'Error updating!';}

    // Close connection
    $conn->close();
}

?>