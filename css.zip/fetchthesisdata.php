<?php

    if (!isset($_GET['tid']) || empty($_GET['tid'])) {echo 'Error fetching!'; exit();}

    include 'variables.php';

    $tid = trim($_GET['tid']);

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    $tid = mysqli_real_escape_string($conn, $tid);

    // SQL Command
    $sql = "SELECT $thesistable.*, $programtable.*, $degreetable.*
        FROM `$thesistable`
        JOIN $programtable ON $thesistable.ProgramID = $programtable.ProgramID
        JOIN $degreetable ON $thesistable.DegreeID = $degreetable.DegreeID
        WHERE $thesistable.ThesisID = '$tid'";

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed");
    }

    // Run
    $result = $conn->query($sql);
    if ($result) {
        $number_of_result = mysqli_num_rows($result);  
        if ($number_of_result == 1) {
            $row = mysqli_fetch_array($result);
            $tid = $row["ThesisID"];
            $title = $row["Title"];
            $author = "";
            $sq = "SELECT * FROM `$thesisauthortable` WHERE ThesisID='$tid'";
            $res = $conn->query($sq);
            while ($r = mysqli_fetch_array($res)) {
                $aid = $r["AuthorID"];
                $sqx = "SELECT * FROM `$authortable` WHERE AuthorID='$aid'";
                $resx = $conn->query($sqx);
                $r = mysqli_fetch_array($resx);
                $author .= $r["Surname"].", ".$r["Firstname"]."\n";
            }
            $pubyear = $row["PublicationYear"];
            $pid = $row["ProgramID"];
            $pname = $row["Program"];
            $did = $row["DegreeID"];
            $dname = $row["Degree"];
            $abstract = $row["Abstract"];
            $authors = trim($author);
            $data = array(
                'tid' => $tid,
                'title' => $title,
                'author' => $authors,
                'pubyear' => $pubyear,
                'abstract' => $abstract,
                'pid' => $pid,
                'did' => $did,
                'program' => $pname,
                'degree' => $dname
            );
            header('Content-Type: application/json');
            echo json_encode($data);
            mysqli_free_result($result);
        }
        else {echo 'Error fetching!';}
    }
    else {echo 'Error fetching!';}

    // Close connection
    $conn->close();

?>