<?php

if (isset($_SESSION['name'])) {echo 'Welcome back '.$_SESSION['name'].'.<br><br>';}

include 'variables.php';
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {echo 'Connection error!';}
else {
    echo '<table cellspacing="0" cellpadding="3" border="0" width="100%">';
    echo '<tr><td>Total Thesis:</td>';
    $sql = "SELECT ThesisID FROM `$thesistable`";
    $r = $conn->query($sql);
    if ($r) {$n = mysqli_num_rows($r); echo '<td>'.$n.'</td>';}
    echo '</tr>';

    echo '<tr><td>Total Author:</td>';
    $sql = "SELECT AuthorID FROM `$authortable`";
    $r = $conn->query($sql);
    if ($r) {$n = mysqli_num_rows($r); echo '<td>'.$n.'</td>';}
    echo '</tr>';

    echo '<tr><td>Total Degree:</td>';
    $sql = "SELECT DegreeID FROM `$degreetable`";
    $r = $conn->query($sql);
    if ($r) {$n = mysqli_num_rows($r); echo '<td>'.$n.'</td>';}
    echo '</tr>';

    echo '<tr><td>Total Program:</td>';
    $sql = "SELECT ProgramID FROM `$programtable`";
    $r = $conn->query($sql);
    if ($r) {$n = mysqli_num_rows($r); echo '<td>'.$n.'</td>';}
    echo '</tr>';

    echo '<tr><td>Total Admin:</td>';
    $sql = "SELECT AdminID FROM `$admintable`";
    $r = $conn->query($sql);
    if ($r) {$n = mysqli_num_rows($r); echo '<td>'.$n.'</td>';}
    echo '</tr>';
    echo '</table>';
}

?>