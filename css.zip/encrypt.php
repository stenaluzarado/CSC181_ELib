<?php

function epass($string) {
    $key = "cGjBkBkAsAlA";
    $cipher = "aes-256-cbc";
    $iv = "1234567890123456";
    $encrypted = openssl_encrypt($string, $cipher, $key, 0, $iv);
    $result = base64_encode($iv.$encrypted);
    return $result;
}

function dpass($string) {
    $key = "cGjBkBkAsAlA";
    $cipher = "aes-256-cbc";
    $data = base64_decode($string);
    $ivlen = openssl_cipher_iv_length($cipher);
    $iv = substr($data, 0, $ivlen);
    $decrypted = openssl_decrypt(substr($data, $ivlen), $cipher, $key, 0, $iv);
    return $decrypted;
}

?>