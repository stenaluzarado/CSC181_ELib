<?php
    echo '<div class="search_container">';
    include 'title.php';
    echo '</div>
        <form id="searchform2" method="GET">
        <table cellspacing="0" cellpadding="0" border="0" class="search_container2">
        <tr>
        <td align="right"><input type="text" id="s2" name="s" placeholder="Search by keywords" class="search_bg"/></td>
        <td><input type="submit" name="submit" value="Go" class="search_btn" style="border-radius:0;"/></td>
        <td><input type="button" id="filterbtn2" name="filterbtn2" value="▼" class="search_btn" onclick="showFilters2()"/></td>
        </tr>
        <tr id="filterholder2" style="display:none;" align="right" valign="top">';
        include 'selectfilters.php';
     echo '</tr></table></form>';
?>