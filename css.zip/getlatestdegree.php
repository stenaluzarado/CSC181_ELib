<?php

if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {

    // Include variables
    include 'variables.php';

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // SQL Command
    $sql = "SELECT * FROM `$degreetable`";

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed");
    }

    // Run
    $result = $conn->query($sql);
    if ($result) {
        $number_of_result = mysqli_num_rows($result);  
        if ($number_of_result > 0) {

            $results_per_page = 10;
            $number_of_page = ceil($number_of_result/$results_per_page);
            if (!empty($_GET['page'])) {$page = $_GET['page'];}
            else {$page = 1;}

            // To understand the limit part $offset is where the selection starts then comma, then the limit.
            $offset = ($page-1)*$results_per_page;
            $sql = "SELECT * FROM `$degreetable` LIMIT ".$offset.",".$results_per_page;
            $result = $conn->query($sql);

            echo '<tr><td class="leftTH" width="10%">No.</td><td class="tableheader" width="70%">Degree</td><td class="rightTH">Degree ID</td></tr>';

            $a = [];
            $cc = 0;
            while ($row = mysqli_fetch_array($result)) {
                $did = $row["DegreeID"];
                $dname = $row["Degree"];
                $a[$cc] = [$did, $dname];
                $cc++;
            }
            $cv = 1;
            $cc = $cc-1;
            while ($cc != -1) {
                $did = $a[$cc][0];
                $dname = $a[$cc][1];
                echo '<tr valign="top" title="Click to perform actions" onclick="fetchdegreedata(\''.$did.'\')"><td class="cells" title="'.$cv.'" align="center">'.$cv.'</td><td class="cells" title="'.$dname.'">'.$dname.'</td><td class="cells" title="'.$did.'" align="center">'.$did.'</td></tr>';
                $cc--;
                $cv++;
            }

            echo '<tr><td colspan="3">';
                if ($result && $number_of_result > 0) {
                    echo "<div class='paginationholder'><span style='margin-right:10px;float:left;'>No. of pages ".$number_of_page."</span>";

                    $number_of_pages_in_pagination = 5;
                    $start = 1;
                    $end = $number_of_pages_in_pagination;
		    if (isset($_GET['pagestart']) && isset($_GET['pageend'])) {
                        $start = $_GET['pagestart'];
                        $end = $_GET['pageend'];
		    }
                    if (empty($start) || empty($end) || $start >= $end ) {$start = 1; $end = $number_of_pages_in_pagination;}
                    if ($page > $end) {$start = $page-($number_of_pages_in_pagination-1); $end = $page;}
                    if ($page < $start) {$start = $page; $end = $page+($number_of_pages_in_pagination-1);}
                    if ($number_of_page < $number_of_pages_in_pagination) {$end = $number_of_page;}

                    $prev = $page-1;
                    if ($prev > 0) {echo "<a class='pagination' href='dashboard.php?dpage=adddegree&page=".$prev."&pagestart=".$start."&pageend=".$end."'>Prev</a>";}
                    for ($p=$start; $p<=$end; $p++) {
                        if ($page == $p) {echo "<a class='currentpagination' href='dashboard.php?dpage=adddegree&page=".$p."&pagestart=".$start."&pageend=".$end."'>".$p."</a>";}
                        else {echo "<a class='pagination' href='dashboard.php?dpage=adddegree&page=".$p."&pagestart=".$start."&pageend=".$end."'>".$p."</a>";}
                    }
                    $next = $page+1;
                    if ($next <= $number_of_page) {echo "<a class='pagination' href='dashboard.php?dpage=adddegree&page=".$next."&pagestart=".$start."&pageend=".$end."'>Next</a>";}
                    echo "</div>";
                }
            echo '</td></tr>';

            mysqli_free_result($result);
        }
        else {echo '<tr><td>No degree in the database.</td></tr>';}
    }

    // Close connection
    $conn->close();

}

?>