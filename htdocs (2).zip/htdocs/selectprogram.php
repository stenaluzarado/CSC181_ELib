<?php
// Include variables
include 'variables.php';

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// SQL Command
$sql = "SELECT * FROM `$programtable`";

// Check connection
if ($conn->connect_error) {
    die("Connection failed");
}

// Run
$result = $conn->query($sql);
if ($result) {
    $number_of_result = mysqli_num_rows($result);  
    if ($number_of_result > 0) {
        echo '<select name="program" class="addinput_bg" id="program" onkeydown="moveToNextInput(event, \'abstract\', \'degree\')"><optgroup class="option" label="Programs">';
        while ($row = mysqli_fetch_array($result)) {
            $id = $row["ProgramID"];
            $name = $row["Program"];
            if (isset($pid) && !empty($pid) && $pid == $id && $pname == $name) {echo '<option class="option" value="'.$id.'" selected>'.$name.'</option>';}
            else {echo '<option class="option" value="'.$id.'">'.$name.'</option>';}
        }
        echo '</optgroup></select>';
    }
    else {
        echo '<select name="program" class="addinput_bg"><optgroup class="option" label="Programs">';
        echo '<option class="option" value="none">Empty program</option>';
        echo '</optgroup></select>';
    }
}

// Close connection
$conn->close();
?>