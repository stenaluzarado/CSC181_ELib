<?php if (isset($s_indicator) && !empty($s_indicator) && $s_indicator == 1) {echo '<script>document.getElementById("search_container_upperlink").style.display = "none";</script>';} ?>

<script src="js/jquery-3.7.1.min.js"></script>
<script>
  document.addEventListener('DOMContentLoaded', function() {
    var table = document.getElementById('latestthesistable');
    table.addEventListener('click', function(event) {
      if (event.target.tagName === 'TD') {
        var rows = table.getElementsByTagName('tr');
        for (var i=0; i<rows.length; i++) {
          rows[i].classList.remove('selected');
        }
        event.target.parentElement.classList.add('selected');
      }
    });
  });
  document.addEventListener('DOMContentLoaded', function() {
    var table = document.getElementById('resultstable');
    table.addEventListener('click', function(event) {
      if (event.target.tagName === 'TD') {
        var rows = table.getElementsByTagName('tr');
        for (var i=0; i<rows.length; i++) {
          rows[i].classList.remove('selected');
        }
        event.target.parentElement.classList.add('selected');
      }
    });
  });
  document.getElementById('bigtitle').addEventListener('click', function() {location.reload(true);});
</script>

<script type="text/javascript">
    function showFilters() {
      var f = document.getElementById("filterholder");
      if (f.style.display === 'block') {f.style.display = 'none';}
      else {f.style.display = 'block';}
    }
    function showFilters2() {
      var f = document.getElementById("filterholder2");
      if (f.style.display === 'block') {f.style.display = 'none';}
      else {f.style.display = 'block';}
    }
    function autoResizeTextarea(textarea) {
        textarea.style.height = 'auto';
        textarea.style.height = (textarea.scrollHeight) + 'px';
    }
    function moveToNextInput(event, nextInputId, prevInputId) {
        if (event.key === "ArrowRight" || event.key === "ArrowDown" || event.key === "ArrowLeft" || event.key === "ArrowUp") {event.preventDefault();}
        if (event.key === "ArrowRight" || event.key === "ArrowDown") {document.getElementById(nextInputId).focus();}
        else if (event.key === "ArrowLeft" || event.key === "ArrowUp") {document.getElementById(prevInputId).focus();}
    }
    function adminActions(tid) {window.location.href = "dashboard.php?dpage=updatesearch&id="+tid;}
    function confirmDialogSearch(id) {
        var result = confirm("Are you sure want to delete it?");
        if (result) {
            $.ajax({
              type: "GET",
              url: "deletethesis.php?id="+id,
              success: function(response) {
                  if (response === "Success") {location.reload(true);}
                  alert(response);
              },
              error: function(error) {}
            });
        }
    }
    function confirmDialog(flag) {
        var result = confirm("Are you sure want to delete it?");
        if (flag == "deletethesis") {if (result) {deleteThesis();}}
        else if (flag == "deletedegree") {if (result) {deleteDegree();}}
        else if (flag == "deleteprogram") {if (result) {deleteProgram();}}
        else if (flag == "deleteadmin") {if (result) {deleteAdmin();}}
        else if (flag == "deleteauthor") {if (result) {deleteAuthor();}}
    }
    function deleteThesis() {
        var id = document.getElementById('deletethesisid').value;
        $.ajax({
          type: "GET",
          url: "deletethesis.php?id="+id,
          success: function(response) {
              if (response === "Success") {location.reload(true);}
              alert(response);
          },
          error: function(error) {}
        });
    }
    function deleteDegree() {
        var id = document.getElementById('deletedegreeid').value;
        $.ajax({
          type: "GET",
          url: "deletedegree.php?id="+id,
          success: function(response) {
              if (response === "Success") {location.reload(true);}
              alert(response);
          },
          error: function(error) {}
        });
    }
    function deleteProgram() {
        var id = document.getElementById('deleteprogramid').value;
        $.ajax({
          type: "GET",
          url: "deleteprogram.php?id="+id,
          success: function(response) {
              if (response === "Success") {location.reload(true);}
              alert(response);
          },
          error: function(error) {}
        });
    }
    function deleteAdmin() {
        var id = document.getElementById('deleteadminid').value;
        $.ajax({
          type: "GET",
          url: "deleteadmin.php?id="+id,
          success: function(response) {
              if (response === "Success") {
                  location.reload(true);
                  alert(response);
              }
              else if (response === "Logout") {window.location.href = "logout.php";}
              else {alert(response);}
          },
          error: function(error) {}
        });
    }
    function deleteAuthor() {
        var id = document.getElementById('deleteauthorid').value;
        $.ajax({
          type: "GET",
          url: "deleteauthor.php?id="+id,
          success: function(response) {
              if (response === "Success") {location.reload(true);}
              alert(response);
          },
          error: function(error) {}
        });
    }
    function fetchresultsdata(tid) {
        $.ajax({
          type: "GET",
          url: "fetchthesisdata.php?tid="+tid,
          dataType: "json",
          success: function(data) {
              var cc = document.getElementById("resultstableabstract");
              cc.innerHTML = 'Abstract<br><br>'+data.abstract.replace(/\r?\n/g, "<br>");
          },
          error: function(error) {}
        });
    }
    function fetchthesisdata(tid) {
        $.ajax({
          type: "GET",
          url: "fetchthesisdata.php?tid="+tid,
          dataType: "json",
          success: function(data) {
              $("#deletethesisid").val(data.tid);
              $("#title").val(data.title);
              autoResizeTextarea(document.getElementById('title'))
              $("#author").val(data.author);
              autoResizeTextarea(document.getElementById('author'))
              $("#pubyear").val(data.pubyear);
              $("#abstract").val(data.abstract);
              autoResizeTextarea(document.getElementById('abstract'))
              $("#degree").val(data.did);
              $("#degree option[value='" + data.did + "']").text(data.degree);
              $("#program").val(data.pid);
              $("#program option[value='" + data.pid + "']").text(data.program);
              document.getElementById('delete').style.display = 'block';
              $("#register").val('Update');
              $("#register").attr('title', 'Update');
          },
          error: function(error) {}
        });
    }
    function fetchdegreedata(id) {
        $.ajax({
          type: "GET",
          url: "fetchdegreedata.php?id="+id,
          dataType: "json",
          success: function(data) {
              $("#deletedegreeid").val(data.did);
              $("#did").val(data.did);
              $("#dname").val(data.dname);
              document.getElementById('delete').style.display = 'block';
              $("#register").val('Update');
              $("#register").attr('title', 'Update');
          },
          error: function(error) {}
        });
    }
    function fetchprogramdata(id) {
        $.ajax({
          type: "GET",
          url: "fetchprogramdata.php?id="+id,
          dataType: "json",
          success: function(data) {
              $("#deleteprogramid").val(data.pid);
              $("#pid").val(data.pid);
              $("#pname").val(data.pname);
              document.getElementById('delete').style.display = 'block';
              $("#register").val('Update');
              $("#register").attr('title', 'Update');
          },
          error: function(error) {}
        });
    }
    function fetchadmindata(id) {
        $.ajax({
          type: "GET",
          url: "fetchadmindata.php?id="+id,
          dataType: "json",
          success: function(data) {
              $("#deleteadminid").val(data.aid);
              $("#uname").val(data.uname);
              $("#pass").val(data.pass);
              document.getElementById('delete').style.display = 'block';
              $("#register").val('Update');
              $("#register").attr('title', 'Update');
          },
          error: function(error) {}
        });
    }
    function fetchauthordata(id) {
        $.ajax({
          type: "GET",
          url: "fetchauthordata.php?id="+id,
          dataType: "json",
          success: function(data) {
              $("#deleteauthorid").val(data.aid);
              $("#fname").val(data.fname);
              $("#sname").val(data.sname);
              document.getElementById('delete').style.display = 'block';
              document.getElementById("update").disabled = false;
              document.getElementById("fname").disabled = false;
              document.getElementById("sname").disabled = false;
              document.getElementById("update").style.opacity = 1;
              document.getElementById("fname").style.opacity = 1;
              document.getElementById("sname").style.opacity = 1;
          },
          error: function(error) {}
        });
    }
</script>
<script>
    $(document).ready(function() {
      $("#searchform").submit(function(event) {
        event.preventDefault();
        var s = document.getElementById('s').value;
        var fsd = document.getElementById('mdegree');
        var fsp = document.getElementById('mprogram');
        var d = "&d=";
        var p = "&p=";
        for (var i=0; i<fsd.options.length; i++) {
            if (fsd.options[i].selected) {d = d+fsd.options[i].value+" ";}
        }
        for (var i=0; i<fsp.options.length; i++) {
            if (fsp.options[i].selected) {p = p+fsp.options[i].value+" ";}
        }
        var dd = d.trim();
        var pp = p.trim();
        $.ajax({
            type: "GET",
            url: "search.php?s="+s+dd+pp,
            data: $("#searchform").serialize(),
            success: function(response) {
                if (response === "Success") {
                    window.location.href = "index.php?s="+s+dd+pp;
                }
                else {alert(response);}
            },
            error: function(error) {}
        });
      });
    });
    $(document).ready(function() {
      $("#searchform2").submit(function(event) {
        event.preventDefault();
        var s = document.getElementById('s2').value;
        var fsd = document.getElementById('mdegree');
        var fsp = document.getElementById('mprogram');
        var d = "&d=";
        var p = "&p=";
        for (var i=0; i<fsd.options.length; i++) {
            if (fsd.options[i].selected) {d = d+fsd.options[i].value+" ";}
        }
        for (var i=0; i<fsp.options.length; i++) {
            if (fsp.options[i].selected) {p = p+fsp.options[i].value+" ";}
        }
        var dd = d.trim();
        var pp = p.trim();
        $.ajax({
            type: "GET",
            url: "search.php?s="+s+dd+pp,
            data: $("#searchform2").serialize(),
            success: function(response) {
                if (response === "Success") {
                    window.location.href = "index.php?s="+s+dd+pp;
                }
                else {alert(response);}
            },
            error: function(error) {}
        });
      });
    });
    $(document).ready(function() {
      $("#login").submit(function(event) {
        event.preventDefault();
        $.ajax({
          type: "POST",
          url: "login.php",
          data: $("#login").serialize(),
          success: function(response) {
              if (response === "Success") {window.location.href = "dashboard.php";}
              else {alert(response);}
          },
          error: function(error) {}
        });
      });
    });
    $(document).ready(function() {
      $("#addadmin").submit(function(event) {
        event.preventDefault();
        var flg = document.getElementById('register').value;
        if (flg == "Register") {
            $.ajax({
              type: "POST",
              url: "addadmin.php",
              data: $("#addadmin").serialize(),
              success: function(response) {
                  if (response === "Success") {
                      location.reload(true);
                  }
                  alert(response);
              },
              error: function(error) {}
            });
        }
        else if (flg == "Update") {
            $.ajax({
              type: "POST",
              url: "updateadmin.php",
              data: $("#addadmin").serialize(),
              success: function(response) {
                  if (response === "Success") {
                      location.reload(true);
                  }
                  alert(response);
              },
              error: function(error) {}
            });
        }
      });
    });
    $(document).ready(function() {
      $("#addprogram").submit(function(event) {
        event.preventDefault();
        var flg = document.getElementById('register').value;
        if (flg == "Register") {
            $.ajax({
              type: "POST",
              url: "addprogram.php",
              data: $("#addprogram").serialize(),
              success: function(response) {
                  if (response === "Success") {
                      location.reload(true);
                  }
                  alert(response);
              },
              error: function(error) {}
            });
        }
        else if (flg == "Update") {
            $.ajax({
              type: "POST",
              url: "updateprogram.php",
              data: $("#addprogram").serialize(),
              success: function(response) {
                  if (response === "Success") {
                      location.reload(true);
                  }
                  alert(response);
              },
              error: function(error) {}
            });
        }
      });
    });
    $(document).ready(function() {
      $("#adddegree").submit(function(event) {
        event.preventDefault();
        var flg = document.getElementById('register').value;
        if (flg == "Register") {
            $.ajax({
              type: "POST",
              url: "adddegree.php",
              data: $("#adddegree").serialize(),
              success: function(response) {
                  if (response === "Success") {
                      location.reload(true);
                  }
                  alert(response);
              },
              error: function(error) {}
            });
        }
        else if (flg == "Update") {
            $.ajax({
              type: "POST",
              url: "updatedegree.php",
              data: $("#adddegree").serialize(),
              success: function(response) {
                  if (response === "Success") {
                      location.reload(true);
                  }
                  alert(response);
              },
              error: function(error) {}
            });
        }
      });
    });
    $(document).ready(function() {
      $("#addthesis").submit(function(event) {
        event.preventDefault();
        var flg = document.getElementById('register').value;
        if (flg == "Register") {
            $.ajax({
              type: "POST",
              url: "addthesis.php",
              data: $("#addthesis").serialize(),
              success: function(response) {
                  if (response === "Success") {
                      location.reload(true);
                  }
                  else if (response.includes("Author existed")) {
                      var result = confirm(response);
                      if (result) {
                          $.ajax({
                              type: "POST",
                              url: "addthesis.php?cont=1",
                              data: $("#addthesis").serialize(),
                              success: function(response) {
                                  if (response === "Success") {location.reload(true);}
                                  else {alert(response);}
                              },
                              error: function(error) {}
                          });
                      }
                  }
                  else {alert(response);}
              },
              error: function(error) {}
            });
        }
        else if (flg == "Update") {
            $.ajax({
              type: "POST",
              url: "updatethesis.php",
              data: $("#addthesis").serialize(),
              success: function(response) {
                  if (response === "Success") {
                      location.reload(true);
                  }
                  alert(response);
              },
              error: function(error) {}
            });
        }
      });
    });
    $(document).ready(function() {
      $("#addauthor").submit(function(event) {
        event.preventDefault();
        $.ajax({
            type: "POST",
            url: "updateauthor.php",
            data: $("#addauthor").serialize(),
            success: function(response) {
                if (response === "Success") {
                    location.reload(true);
                }
                alert(response);
            },
            error: function(error) {}
        });
      });
    });
</script>