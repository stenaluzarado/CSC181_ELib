<?php
// Include variables
include 'variables.php';

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// SQL Command
$sql = "SELECT * FROM `$degreetable`";
$sql2 = "SELECT * FROM `$programtable`";

// Check connection
if ($conn->connect_error) {
    die("Connection failed");
}

// Run
$result = $conn->query($sql);
if ($result) {
    $n = mysqli_num_rows($result);  
    if ($n > 0) {
        $n++;
        echo '<td style="padding:10px 10px 0 0;"><select name="mdegree[]" class="multiselect" id="mdegree" multiple size="'.$n.'"><optgroup class="option" label="Filter Degrees">';
        while ($row = mysqli_fetch_array($result)) {
            $id = $row["DegreeID"];
            $name = $row["Degree"];
            echo '<option class="option" value="'.$id.'">'.$name.'</option>';
        }
        echo '</optgroup></select></td>';
    }
    else {
        echo '<td><select name="mdegree[]" class="multiselect" id="mdegree" multiple><optgroup class="option" label="Filter Degrees">';
        echo '<option class="option" value="none">Empty degree</option>';
        echo '</optgroup></select></td>';
    }
}
$result = $conn->query($sql2);
if ($result) {
    $n = mysqli_num_rows($result);  
    if ($n > 0) {
        $n++;
        echo '<td style="padding:10px 10px 0 0;"><select name="mprogram[]" class="multiselect" id="mprogram" multiple size="'.$n.'"><optgroup class="option" label="Filter Program">';
        while ($row = mysqli_fetch_array($result)) {
            $id = $row["ProgramID"];
            $name = $row["Program"];
            echo '<option class="option" value="'.$id.'">'.$name.'</option>';
        }
        echo '</optgroup></select></td>';
    }
    else {
        echo '<td><select name="mprogram[]" class="multiselect" id="mprogram" multiple><optgroup class="option" label="Filter Program">';
        echo '<option class="option" value="none">Empty program</option>';
        echo '</optgroup></select></td>';
    }
}

// Close connection
$conn->close();
?>