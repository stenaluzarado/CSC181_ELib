<?php

session_start();

if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
    if (!isset($_GET['id']) || empty($_GET['id'])) {echo 'Error fetching!'; exit();}

    include 'variables.php';

    $id = trim($_GET['id']);

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    $id = mysqli_real_escape_string($conn, $id);

    // SQL Command
    $sql = "SELECT * FROM `$admintable` WHERE AdminID = '$id'";

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed");
    }

    // Run
    $result = $conn->query($sql);
    if ($result) {
        $number_of_result = mysqli_num_rows($result);  
        if ($number_of_result == 1) {
            $row = mysqli_fetch_array($result);
            $aid = $row["AdminID"];
            $uname = $row["Username"];
            $pass = $row["Password"];
            $data = array(
                'aid' => $aid,
                'uname' => $uname,
                'pass' => $pass
            );
            header('Content-Type: application/json');
            echo json_encode($data);
            mysqli_free_result($result);
        }
        else {echo 'Error fetching!';}
    }
    else {echo 'Error fetching!';}

    // Close connection
    $conn->close();

}

?>