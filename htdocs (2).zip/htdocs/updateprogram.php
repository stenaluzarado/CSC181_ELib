<?php

session_start();

if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
    if (!isset($_POST['deleteprogramid']) || empty($_POST['deleteprogramid']) || !isset($_POST['pid']) || empty($_POST['pid']) || !isset($_POST['pname']) || empty($_POST['pname'])) {echo 'Error updating!'; exit();}

    include 'variables.php';

    $delid = trim($_POST['deleteprogramid']);
    $id = trim($_POST['pid']);
    $name = trim($_POST['pname']);

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    $delid = mysqli_real_escape_string($conn, $delid);
    $id = mysqli_real_escape_string($conn, $id);
    $name = mysqli_real_escape_string($conn, $name);

    // SQL Command
    $sql = "SELECT * FROM `$programtable` WHERE ProgramID='$id' OR Program='$name'";
    $sql2 = "UPDATE `$programtable`
            SET
            ProgramID = '$id',
            Program = '$name'
            WHERE ProgramID = '$delid'";
    $sql3 = "UPDATE `$thesistable`
            SET
            ProgramID = '$id'
            WHERE ProgramID = '$delid'";

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed");
    }

    // Run
    $result = $conn->query($sql);
    if ($result) {
        $number_of_result = mysqli_num_rows($result);  
        if ($number_of_result == 0) {
            $result = $conn->query($sql2);
            if ($result) {
                $result = $conn->query($sql3);
                if ($result) {echo 'Success';}
                else {echo 'Error updating!';}
            }
            else {echo 'Error updating!';}
        }
        else {
            if ($delid == $id) {
                $sql = "SELECT * FROM `$programtable` WHERE Program='$name'";
                $result = $conn->query($sql);
                if ($result) {
                    $n = mysqli_num_rows($result);  
                    if ($n == 0) {
                        $result = $conn->query($sql2);
                        if ($result) {
                            $result = $conn->query($sql3);
                            if ($result) {echo 'Success';}
                            else {echo 'Error updating!';}
                        }
                        else {echo 'Error updating!';}
                    }
                    else {echo 'Program exists!';}
                }
                else {echo 'Error updating!';}
            }
            else {echo 'Program exists!';}
        }
    }
    else {echo 'Error updating!';}

    // Close connection
    $conn->close();
}

?>