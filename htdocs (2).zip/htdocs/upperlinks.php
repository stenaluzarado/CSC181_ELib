<?php
    if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
        echo '<a href="logout.php" class="upperlinks" style="margin-right:30px;">Logout</a>';
        echo '<a href="dashboard.php" class="upperlinks" style="margin-right:150px;">Dashboard</a>';
        echo '<a href="index.php" class="upperlinks" style="margin-right:300px;">Home</a>
              <form id="searchform" method="GET">';
        echo '<table cellspacing="0" cellpadding="0" border="0" id="search_container_upperlink" class="search_container_upperlink" style="margin-right:420px;">
              <tr>
              <td align="right"><input type="text" id="s" name="s" placeholder="Search by keywords" class="search_bg_upperlink"/></td>
              <td><input type="submit" name="submit" value="Go" class="search_btn_upperlink" style="border-radius:0;"/></td>
              <td><input type="button" id="filterbtn" name="filterbtn" value="▼" class="search_btn_upperlink" onclick="showFilters()"/></td>
              </tr>
              <tr id="filterholder" style="display:none;" align="right" valign="top">';
              include 'selectfilters.php';
        echo '</tr></table></form>';
    }
    else {
        echo '<a href="admin.php" class="upperlinks" style="margin-right:30px;">Login</a>';
        echo '<a href="index.php" class="upperlinks" style="margin-right:140px;">Home</a>
              <form id="searchform" method="GET">';
        echo '<table cellspacing="0" cellpadding="0" border="0" id="search_container_upperlink" class="search_container_upperlink" style="margin-right:255px;">
              <tr>
              <td align="right"><input type="text" id="s" name="s" placeholder="Search by keywords" class="search_bg_upperlink"/></td>
              <td><input type="submit" name="submit" value="Go" class="search_btn_upperlink" style="border-radius:0;"/></td>
              <td><input type="button" id="filterbtn" name="filterbtn" value="▼" class="search_btn_upperlink" onclick="showFilters()"/></td>
              </tr>
              <tr id="filterholder" style="display:none;" align="right" valign="top">';
              include 'selectfilters.php';
        echo '</tr></table></form>';
    }
?>
