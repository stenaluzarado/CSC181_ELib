<?php

session_start();

if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
    if (!isset($_POST['title']) || empty($_POST['title']) || !isset($_POST['degree']) || empty($_POST['degree']) || !isset($_POST['author']) || empty($_POST['author']) || !isset($_POST['program']) || empty($_POST['program']) || !isset($_POST['abstract']) || empty($_POST['abstract']) || !isset($_POST['pubyear']) || empty($_POST['pubyear'])) {echo 'Error adding!'; exit();}

    include 'variables.php';

    $title = trim($_POST['title']);
    $au = trim($_POST['author']);
    $degreeid = trim($_POST['degree']);
    $programid = trim($_POST['program']);
    $pubyear = trim($_POST['pubyear']);
    $abstract = trim($_POST['abstract']);

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    $authors = [];
    $as = explode("\n", $au);
    foreach ($as as $aut) {
        $a = explode(",", $aut);
        if (count($a) < 2) {echo 'Error adding!'; exit();}
        $fn = trim($a[1]);
        $ln = trim($a[0]);
        $fn = mysqli_real_escape_string($conn, $fn);
        $ln = mysqli_real_escape_string($conn, $ln);
        $authors[] = [$ln, $fn];
    }

    $title = mysqli_real_escape_string($conn, $title);
    $degreeid = mysqli_real_escape_string($conn, $degreeid);
    $programid = mysqli_real_escape_string($conn, $programid);
    $pubyear = mysqli_real_escape_string($conn, $pubyear);
    $abstract = mysqli_real_escape_string($conn, $abstract);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed");
    }

    if (!isset($_GET['cont']) || empty($_GET['cont'])) {
        $laua = "";
        foreach ($authors as $a) {
            $sql = "SELECT AuthorID FROM `$authortable` WHERE Firstname='$a[1]' AND Surname='$a[0]' OR Firstname='$a[0]' AND Surname='$a[1]'";
            $result = $conn->query($sql);
            if ($result && mysqli_num_rows($result) != 0) {$laua .= "- ".$a[0].", ".$a[1]."\n";}
        }
        $lau = trim($laua);
        if (isset($lau) && !empty($lau)) {echo "Author existed!\n\n".$lau."\n\nIf the authors above are the same person in the database, then please click ok to continue saving.\n\nBut if they are not, please consider to put prefix or suffix or number to distinguish authors with the same names."; exit();}
    }

    // SQL Command
    $sql = "INSERT INTO `$thesistable` (ProgramID, DegreeID, Title, PublicationYear, Abstract) VALUES ('$programid', '$degreeid', '$title', '$pubyear', '$abstract')";

    // Run
    $result = $conn->query($sql);
    if ($result) {
        $lastThesisID = $conn->insert_id;
        foreach ($authors as $a) {
            $sql = "SELECT AuthorID FROM `$authortable` WHERE Firstname='$a[1]' AND Surname='$a[0]' OR Firstname='$a[0]' AND Surname='$a[1]'";
            $result = $conn->query($sql);
            if ($result && mysqli_num_rows($result) == 0) {
                $sql = "INSERT INTO `$authortable` (Firstname, Surname) VALUES ('$a[1]', '$a[0]')";
                $result = $conn->query($sql);
                if ($result) {
                    $lastAuthorID = $conn->insert_id;
                    $sql = "INSERT INTO `$thesisauthortable` (ThesisID, AuthorID) VALUES ('$lastThesisID', '$lastAuthorID')";
                    if ($conn->query($sql) !== TRUE) {echo 'Error adding!'; exit();}
                }
                else {echo 'Error adding!'; exit();}
            }
            else {
                $r = mysqli_fetch_array($result);
                $aid = $r['AuthorID'];
                $sql = "SELECT AuthorID FROM `$thesisauthortable` WHERE ThesisID='$lastThesisID' AND AuthorID='$aid'";
                $result = $conn->query($sql);
                if ($result && mysqli_num_rows($result) == 0) {
                    $sql = "INSERT INTO `$thesisauthortable` (ThesisID, AuthorID) VALUES ('$lastThesisID', '$aid')";
                    if ($conn->query($sql) !== TRUE) {echo 'Error adding!'; exit();}
                }
            }
        }
        echo 'Success';
    }
    else {echo 'Error adding!';}

    // Close connection
    $conn->close();
}

?>