<?php

session_start();

if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
    if (!isset($_POST['did']) || empty($_POST['did']) || !isset($_POST['dname']) || empty($_POST['dname'])) {echo 'Error registering!'; exit();}

    include 'variables.php';

    $did = trim($_POST['did']);
    $dname = trim($_POST['dname']);

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    $did = mysqli_real_escape_string($conn, $did);
    $dname = mysqli_real_escape_string($conn, $dname);

    // SQL Command
    $sql = "SELECT Degree FROM `$degreetable` WHERE DegreeID='$did' OR Degree='$dname'";
    $sql2 = "INSERT INTO `$degreetable` (DegreeID, Degree) VALUES ('$did', '$dname')";

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed");
    }

    // Run
    $result = $conn->query($sql);
    if ($result) {
        $number_of_result = mysqli_num_rows($result);  
        if ($number_of_result == 0) {
            $result2 = $conn->query($sql2);
            if ($result2) {echo 'Success';}
            else {echo 'Error registering!';}
        }
        else {echo 'Degree exists!';}
    }
    else {echo 'Error registering!';}

    // Close connection
    $conn->close();
}

?>