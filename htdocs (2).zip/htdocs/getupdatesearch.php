<?php

if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {

    // Include variables
    include 'variables.php';

    $id = trim($_GET['id']);

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    $id = mysqli_real_escape_string($conn, $id);

    // SQL Command
    $sql = "SELECT $thesistable.*, $programtable.*, $degreetable.*
            FROM `$thesistable`
            JOIN $programtable ON $thesistable.ProgramID = $programtable.ProgramID
            JOIN $degreetable ON $thesistable.DegreeID = $degreetable.DegreeID
            WHERE $thesistable.ThesisID = '$id'";

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed");
    }

    // Run
    $result = $conn->query($sql);
    if ($result) {
        $number_of_result = mysqli_num_rows($result);  
        if ($number_of_result > 0) {
            echo '<tr><td class="leftTH" width="40%">Title</td><td class="tableheader">Author</td><td class="tableheader">Publication Year</td><td class="tableheader">Program</td><td class="rightTH">Degree</td></tr>';

            while ($row = mysqli_fetch_array($result)) {
                $tid = $row["ThesisID"];
                $title = $row["Title"];

                $author = "";
                $sq = "SELECT * FROM `$thesisauthortable` WHERE ThesisID='$tid'";
                $res = $conn->query($sq);
                while ($r = mysqli_fetch_array($res)) {
                    $aid = $r['AuthorID'];
                    $sqx = "SELECT * FROM `$authortable` WHERE AuthorID='$aid'";
                    $resx = $conn->query($sqx);
                    $r = mysqli_fetch_array($resx);
                    $author .= $r['Surname'].", ".$r['Firstname']."<br>";
                }

                $pubyear = $row["PublicationYear"];
                $pid = $row["ProgramID"];
                $pname = $row["Program"];
                $did = $row["DegreeID"];
                $dname = $row["Degree"];
                $abstract = $row["Abstract"];
                echo '<tr valign="top" title="Click to perform actions" onclick="fetchthesisdata(\''.$tid.'\')"><td class="cells">'.$title.'</td><td class="cells">'.trim($author).'</td><td class="cells" align="center">'.$pubyear.'</td><td class="cells" title="'.$pname.'" align="center">'.$pid.'</td><td class="cells" title="'.$dname.'" align="center">'.$did.'</td></tr>';
            }

            echo '<tr><td colspan="5"><div class="paginationholder" style="text-align:center;">Please click the thesis item to update or delete.</div></td></tr>';

            mysqli_free_result($result);
        }
        else {echo '<tr><td>No thesis in the database.</td></tr>';}
    }

    // Close connection
    $conn->close();

}

?>