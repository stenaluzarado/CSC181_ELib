<?php

session_start();

if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
    if (!isset($_POST['deleteauthorid']) || empty($_POST['deleteauthorid']) || !isset($_POST['fname']) || empty($_POST['fname']) || !isset($_POST['sname']) || empty($_POST['sname'])) {echo 'Error updating!'; exit();}

    include 'variables.php';

    $id = trim($_POST['deleteauthorid']);
    $fn = trim($_POST['fname']);
    $ln = trim($_POST['sname']);

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    $id = mysqli_real_escape_string($conn, $id);
    $fn = mysqli_real_escape_string($conn, $fn);
    $ln = mysqli_real_escape_string($conn, $ln);

    // SQL Command
    $sql = "SELECT * FROM `$authortable` WHERE Firstname='$fn' AND Surname='$ln' OR Firstname='$ln' AND Surname='$fn'";
    $sql2 = "UPDATE `$authortable`
            SET
            Firstname = '$fn',
            Surname = '$ln'
            WHERE AuthorID = '$id'";

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed");
    }

    // Run
    $result = $conn->query($sql);
    if ($result) {
        $number_of_result = mysqli_num_rows($result);  
        if ($number_of_result == 0) {
            $result = $conn->query($sql2);
            if ($result) {echo 'Success';}
            else {echo 'Error updating!';}
        }
        else {
            $row = mysqli_fetch_array($result);
            if ($id == $row['AuthorID']) {
                $result = $conn->query($sql2);
                if ($result) {echo 'Success';}
                else {echo 'Error updating!';}
            }
            else {echo 'Author exists!';}
        }
    }
    else {echo 'Error updating!';}

    // Close connection
    $conn->close();
}

?>