<?php
    session_start();
    $_SESSION['role'] = '';
    $_SESSION['name'] = '';
    header("Location: index.php");
    exit();
?>
