<?php

$s_indicator = 0;
// We use indicator to detect if we hide search bar in upperlinks.php or we show it.
// It is connected to footer.php

if (!isset($_GET['s']) || empty($_GET['s'])) {
    include 'searchgui.php';
    $s_indicator = 1;
}
else {
    include 'variables.php';

    $s = trim($_GET['s']);
    $d = '';
    $pr = '';
    if (isset($_GET['d']) && !empty($_GET['d'])) {$d = trim($_GET['d']);}
    if (isset($_GET['p']) && !empty($_GET['p'])) {$pr = trim($_GET['p']);}

    $a = explode(" ", $d);
    $b = explode(" ", $pr);

    $conditions = array();
    if (!empty($a) && (count($a) > 1 || !empty($a[0]))) {
        foreach ($a as $degree) {
            if (!empty($degree)) {
                if (!empty($b) && (count($b) > 1 || !empty($b[0]))) {
                    foreach ($b as $program) {
                        if (!empty($program)) {
                            $conditions[] = "$thesistable.DegreeID='$degree' AND $thesistable.ProgramID='$program'";
                        }
                    }
                }
                else {
                    $conditions[] = "$thesistable.DegreeID='$degree'";
                }
            }
        }
    }
    elseif (!empty($b) && (count($b) > 1 || !empty($b[0]))) {
        foreach ($b as $program) {
            if (!empty($program)) {
                $conditions[] = "$thesistable.ProgramID='$program'";
            }
        }
    }
    $conditions_str = implode(' OR ', $conditions);
    if (!empty($conditions_str)) {
        $conditions_str = "AND ($conditions_str)";
    }

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    $s = mysqli_real_escape_string($conn, $s);

    // SQL Command
    $sql = "SELECT * FROM `$thesistable` WHERE Abstract LIKE '%$s%' $conditions_str OR Title LIKE '%$s%' $conditions_str";

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed");
    }

    // Run
    $result = $conn->query($sql);
    if ($result) {
        $abs = "";
        $number_of_result = mysqli_num_rows($result);  
        if ($number_of_result > 0) {
            echo '<a id="bigtitle" href="javascript:void(0);" onclick="location.reload();" class="smalltitle">'.$number_of_result.' search results for "'.$s.'"</a>';
            echo '<table cellpadding="0" cellspacing="20" border="0" width="66%" style="position:absolute;top:100;left:10;"><tr valign="top"><td>';
            echo '<table id="resultstable" cellpadding="10" cellspacing="0" border="0">';
            $results_per_page = 10;
            $number_of_page = ceil($number_of_result/$results_per_page);
            if (!empty($_GET['page'])) {$page = $_GET['page'];}
            else {$page = 1;}

            // To understand the limit part $offset is where the selection starts then comma, then the limit.
            $offset = ($page-1)*$results_per_page;
            $sql = "SELECT $thesistable.*, $programtable.*, $degreetable.*
                FROM `$thesistable`
                JOIN $programtable ON $thesistable.ProgramID = $programtable.ProgramID
                JOIN $degreetable ON $thesistable.DegreeID = $degreetable.DegreeID
                WHERE $thesistable.Abstract LIKE '%$s%' $conditions_str OR $thesistable.Title LIKE '%$s%' $conditions_str
                ORDER BY $thesistable.ThesisID LIMIT ".$offset.",".$results_per_page;
            $result = $conn->query($sql);
            echo '<tr><td class="leftTH" width="10%">Count</td><td class="tableheader" width="40%">Title</td><td class="tableheader">Author</td><td class="tableheader">Publication Year</td><td class="tableheader">Program</td><td class="rightTH">Degree</td></tr>';

            $results = [];
            while ($row = $result->fetch_assoc()) {$results[] = $row;}
            usort($results, function($a, $b) use ($s) {
                $counta = substr_count(strtolower($a["Title"].' '.$a["Abstract"]), strtolower($s));
                $countb = substr_count(strtolower($b["Title"].' '.$b["Abstract"]), strtolower($s));
                return $countb-$counta;
            });
            foreach ($results as $row) {
                $tid = $row["ThesisID"];
                $title = $row["Title"];

                $author = "";
                $sq = "SELECT * FROM `$thesisauthortable` WHERE ThesisID='$tid'";
                $res = $conn->query($sq);
                while ($r = mysqli_fetch_array($res)) {
                    $aid = $r['AuthorID'];
                    $sqx = "SELECT * FROM `$authortable` WHERE AuthorID='$aid'";
                    $resx = $conn->query($sqx);
                    $r = mysqli_fetch_array($resx);
                    $author .= $r['Surname'].", ".$r['Firstname']."<br>";
                }

                $pubyear = $row["PublicationYear"];
                $pid = $row["ProgramID"];
                $pname = $row["Program"];
                $did = $row["DegreeID"];
                $dname = $row["Degree"];
                $abstract = $row["Abstract"];
                if (empty($abs)) {$abs = $abstract;}
                $count = substr_count(strtolower($title.' '.$abstract), strtolower($s));
                echo '<tr valign="top" title="Click to show abstract" onclick="fetchresultsdata(\''.$tid.'\')"><td class="cells" align="center">';
                if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
                    echo '<input id="actionsbtn" type="button" onclick="adminActions(\''.$tid.'\')" title="Update" value="Update" class="action_btn"/>';
                    echo '<input id="actionsbtndel" type="button" onclick="confirmDialogSearch(\''.$tid.'\')" title="Delete" value="Delete" class="action_btn" style="background:red;left:100;"/>';
                }
                echo $count.'</td><td class="cells">'.$title.'</td><td class="cells">'.$author.'</td><td class="cells" align="center">'.$pubyear.'</td><td class="cells" title="'.$pname.'" align="center">'.$pid.'</td><td class="cells" title="'.$dname.'" align="center">'.$did.'</td></tr>';
            }

            echo '<tr><td colspan="6">';
                if ($result && $number_of_result > 0) {
                    echo "<div class='paginationholder'><span style='margin-right:10px;float:left;'>No. of pages ".$number_of_page."</span>";

                    $number_of_pages_in_pagination = 5;
                    $start = 1;
                    $end = $number_of_pages_in_pagination;
		    if (isset($_GET['pagestart']) && isset($_GET['pageend'])) {
                        $start = $_GET['pagestart'];
                        $end = $_GET['pageend'];
		    }
                    if (empty($start) || empty($end) || $start >= $end ) {$start = 1; $end = $number_of_pages_in_pagination;}
                    if ($page > $end) {$start = $page-($number_of_pages_in_pagination-1); $end = $page;}
                    if ($page < $start) {$start = $page; $end = $page+($number_of_pages_in_pagination-1);}
                    if ($number_of_page < $number_of_pages_in_pagination) {$end = $number_of_page;}

                    $prev = $page-1;
                    if ($prev > 0) {echo "<a class='pagination' href='index.php?s=".$s."&d=".$d."&p=".$pr."&page=".$prev."&pagestart=".$start."&pageend=".$end."'>Prev</a>";}
                    for ($p=$start; $p<=$end; $p++) {
                        if ($page == $p) {echo "<a class='currentpagination' href='index.php?s=".$s."&d=".$d."&p=".$pr."&page=".$p."&pagestart=".$start."&pageend=".$end."'>".$p."</a>";}
                        else {echo "<a class='pagination' href='index.php?s=".$s."&d=".$d."&p=".$pr."&page=".$p."&pagestart=".$start."&pageend=".$end."'>".$p."</a>";}
                    }
                    $next = $page+1;
                    if ($next <= $number_of_page) {echo "<a class='pagination' href='index.php?s=".$s."&d=".$d."&p=".$pr."&page=".$next."&pagestart=".$start."&pageend=".$end."'>Next</a>";}
                    echo "</div>";
                }
            echo '</td></tr>';
            echo '</table>';
            echo '</td></tr></table>';
            echo '<table cellpadding="0" cellspacing="20" border="0" width="30%" style="position:absolute;top:100;right:50;"><tr valign="top"><td>';
            echo '<div id="resultstableabstract">Abstract<br><br>'.nl2br($abs).'</div>';
            echo '</td></tr></table>';
            echo '<a href="getsearchresultsdownload.php?s='.$s.'&d='.$d.'&p='.$pr.'" title="Download" class="download_btn">Download Results</a>';
            mysqli_free_result($result);
        }
        else {
            include 'searchgui.php';
            $s_indicator = 1;
        }
    }

    // Close connection
    $conn->close();
}

?>