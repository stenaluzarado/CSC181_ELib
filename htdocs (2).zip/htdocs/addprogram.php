<?php

session_start();

if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
    if (!isset($_POST['pid']) || empty($_POST['pid']) || !isset($_POST['pname']) || empty($_POST['pname'])) {echo 'Error registering!'; exit();}

    include 'variables.php';

    $pid = trim($_POST['pid']);
    $pname = trim($_POST['pname']);

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    $pid = mysqli_real_escape_string($conn, $pid);
    $pname = mysqli_real_escape_string($conn, $pname);

    // SQL Command
    $sql = "SELECT Program FROM `$programtable` WHERE ProgramID='$pid' OR Program='$pname'";
    $sql2 = "INSERT INTO `$programtable` (ProgramID, Program) VALUES ('$pid', '$pname')";

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed");
    }

    // Run
    $result = $conn->query($sql);
    if ($result) {
        $number_of_result = mysqli_num_rows($result);  
        if ($number_of_result == 0) {
            $result2 = $conn->query($sql2);
            if ($result2) {echo 'Success';}
            else {echo 'Error registering!';}
        }
        else {echo 'Program exists!';}
    }
    else {echo 'Error registering!';}

    // Close connection
    $conn->close();
}

?>