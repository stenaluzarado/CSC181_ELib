<?php

session_start();

if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
    if (!isset($_POST['uname']) || empty($_POST['uname']) || !isset($_POST['pass']) || empty($_POST['pass'])) {echo 'Error registering!'; exit();}

    include 'variables.php';

    $uname = trim($_POST['uname']);
    $pass = trim($_POST['pass']);

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    $uname = mysqli_real_escape_string($conn, $uname);
    $pass = mysqli_real_escape_string($conn, $pass);

    include 'encrypt.php';
    $pass = epass($pass);

    // SQL Command
    $sql = "SELECT Username FROM `$admintable` WHERE BINARY Username='$uname'";
    $sql2 = "INSERT INTO `$admintable` (Username, Password) VALUES ('$uname', '$pass')";

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed");
    }

    // Run
    $result = $conn->query($sql);
    if ($result) {
        $number_of_result = mysqli_num_rows($result);  
        if ($number_of_result == 0) {
            $result2 = $conn->query($sql2);
            if ($result2) {echo 'Success';}
            else {echo 'Error registering!';}
        }
        else {echo 'Username exists!';}
    }
    else {echo 'Error registering!';}

    // Close connection
    $conn->close();
}

?>