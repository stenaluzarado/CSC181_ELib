<html>

<head>
    <?php include 'head.php';?>
</head>

<body>

<div class="search_container">
    <?php include 'title.php';?>
</div>
    <form id="login" action="login.php" method="POST">
        <table cellspacing="0" cellpadding="10" border="0" class="search_container2"><tr>
        <td><input type="text" name="uname" placeholder="Username" class="input_bg" id="uname" onkeydown="moveToNextInput(event, 'pass', 'pass')"/></td>
        <td><input type="password" name="pass" placeholder="Password" class="input_bg" id="pass" onkeydown="moveToNextInput(event, 'uname', 'uname')"/></td>
        <td><input type="submit" title="Login" value="Login" class="input_btn"/></td>
        </tr></table>
    </form>

<?php include 'upperlinks.php';?>
<?php include 'footer.php';?>

</body>

</html>
